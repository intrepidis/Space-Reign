(function (global) {
	"use strict";
	
	var spaceReign = global.spaceReign = global.spaceReign || {},
	log = global.cmnLog,
	cmnMisc = global.cmnMisc,
	rand = cmnMisc.rand,
	cmnSpatial = global.cmnSpatial,
	Vector = cmnSpatial.Vector,
	initialSettings = spaceReign.initialSettings,
	TradeItem = spaceReign.TradeItem,
	Solar = spaceReign.Solar,
	ShipClass = spaceReign.ShipClass,
	Vessel = spaceReign.Vessel,
	tradeGoods = spaceReign.tradeGoods,
	shipClasses = spaceReign.shipClasses,
	starMap = spaceReign.starMap;
	
	spaceReign.vessels = (function () {
		var I = {}; // I will be the returned object instance.
		
		// This is how far through the ship list "iterateTask" has traversed.
		I.taskStateIndex = 0;
		
		// This is how many jobs "iterateTask" needs to do. (The number of ships currently in transit.)
		I.taskCount = 0;
		Object.defineProperty(I, 'taskCount', {
			get : function () {
				return I.allShips.length;
			}
		});
		
		// Here is the portion that "iterateTask" is allowed process in one calling.
		I.taskPortion = cmnMisc.maxInt32;
		
		// The array of all ships in the game.
		I.allShips = (function () {
			var i,
			ar;
			
			function makeShip() {
				var classIndex,
				vx,
				vy,
				coord,
				dest,
				ship,
				v2 = new Vector(2, 2);
				
				function chooseSystem() {
					var sectorCenter,
					solars;
					sectorCenter = initialSettings.sectorCount.div(v2);
					solars = starMap.space[sectorCenter.x][sectorCenter.y];
					if (solars.length === 0) {
						// A fix for when a sector doesn't have any stars.
						return new Solar();
					}
					return solars[rand.nextRangedInt(solars.length)];
				}
				
				// Now make the Vessel object.
				classIndex = rand.nextRangedInt(shipClasses.length);
				// (Sizes are relative to the sector size which has a width, height and depth of 1.)
				vx = rand.nextRangedFloat(1);
				vy = rand.nextRangedFloat(1);
				coord = initialSettings.sectorCount.div(v2).add(new Vector(vx, vy, 0));
				dest = chooseSystem();
				ship = new Vessel(undefined, classIndex, coord, dest);
				return ship;
			}
			
			ar = [];
			for (i = 0; i < initialSettings.initialNumberOfShips; i++) {
				ar.push(makeShip());
			}
			return ar;
		}
			());
		
		// This manages the coordination of vessels.
		I.iterateTask = function () {
			var i,
			s,
			startIndex,
			tuple,
			endIndex,
			extraEndIndex,
			dilation = I.taskCount / I.taskPortion;
			
			// A function to move a coordinate closer to a destination.
			// Returns the tuple (newCoordinate : DepthPoint, isAtDestination : bool)
			function moveStep(hereCoord, thereCoord, moveDistance) {
				var distCoord,
				fullDistance,
				ratio,
				ratioVector,
				result;
				
				distCoord = thereCoord.sub(hereCoord);
				fullDistance = distCoord.length;
				if (moveDistance > fullDistance) {
					// The move distance will over-shoot the target, so just return the destination.
					return {
						coord : thereCoord,
						arrived : true
					};
				}
				ratio = moveDistance / fullDistance;
				ratioVector = new Vector(ratio, ratio);
				result = hereCoord.add(distCoord).mul(ratioVector);
				return {
					coord : result,
					arrived : false
				};
			}
			
			// A function to move a ship closer to it's destination.
			function moveShip(ship) {
				if (!ship.arrived) {
					var v = moveStep(ship.coord, ship.dest.coord, (shipClasses[ship.classIndex].speed * dilation));
					ship.coord = v.coord;
					ship.arrived = v.arrived;
				}
			}
			
			// Move the allowed portion of ships *that are currently in transit*.
			startIndex = I.taskStateIndex;
			tuple = (function () {
				var e,
				count;
				
				count = I.allShips.length;
				e = -1 + startIndex + (I.taskPortion > count ? count : I.taskPortion);
				
				if (e < count) {
					return [e, -1];
				}
				
				return [count - 1, e - count];
			}
				());
			endIndex = tuple[0];
			extraEndIndex = tuple[1];
			
			// Here I should be splitting the list into left, middle and right segments
			// and then joining them back after, perhaps.
			
			// Do the right portion.
			for (i = startIndex; i <= endIndex; i++) {
				moveShip(I.allShips[i]);
			}
			
			// Do the left portion.
			if (extraEndIndex >= 0) {
				for (i = 0; i <= extraEndIndex; i++) {
					moveShip(I.allShips[i]);
				}
				I.taskStateIndex = extraEndIndex + 1;
			} else {
				s = endIndex + 1;
				I.taskStateIndex = (s === I.allShips.length) ? 0 : s;
			}
		};
		
		return I;
	}
		());
}
	(this));
