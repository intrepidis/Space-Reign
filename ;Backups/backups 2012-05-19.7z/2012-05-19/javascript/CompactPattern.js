(function (global) {
	"use strict";
	
	var nasherNS = global.nasherNS = global.nasherNS = {};
	
	nasherNS.singletonExample = (function () {
		var I = {}, // I will be the returned object instance.
		
		// Private members:
		toggle = false,
		text = '';
		
		// Public members:
		I.count = 0;
		I.numbers = [1, 2, 3];
		
		// A public instance method. (Remember that copies of this function could be made.)
		I.incrementNumbersByCount = function () {
			var i;
			for (i = 0; i < I.numbers.length; i++) {
				I.numbers[i] += I.count;
			}
		};
		
		// This is how a public field would have property accessors applied:
		I.numberCount = 0;
		Object.defineProperty(I, 'numberCount', {
			get : function () {
				return this.numbers.length;
			}
		});
		
		// A function that uses some of the above.
		I.tweak = function () {
			toggle = !toggle;
			if (toggle) {
				I.count++;
			}
			text = 'tweaked';
		};
		
		// Return the object instance.
		return I;
	}
		());
	
	nasherNS.TypeExample = (function () {
		var U = function () { // U is the type and here is it's constructor.
			// Pseudo-private members:
			var priv = this.priv = {};
			priv.toggle = false;
			priv.text = '';
			
			// Public members:
			this.count = 0;
			this.numbers = [1, 2, 3];
			
			// This is how a public field would have property accessors applied:
			this.numberCount = 0;
			Object.defineProperty(this, 'numberCount', {
				get : function () {
					return this.numbers.length;
				}
			});
		};
		
		// Public prototype functions:
		U.prototype = {
			incrementNumbersByCount : function () {
				var i;
				for (i = 0; i < this.numbers.length; i++) {
					this.numbers[i] += this.count;
				}
			},
			tweak : function () {
				var priv = this.priv;
				priv.toggle = !priv.toggle;
				if (priv.toggle) {
					this.count++;
				}
				priv.text = 'tweaked';
			}
		};
		
		return U;
	}
		());
}
	(this));
