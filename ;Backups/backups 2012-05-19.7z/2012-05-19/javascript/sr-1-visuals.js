﻿(function (global) {
	"use strict";
	
	var spaceReign = global.spaceReign = global.spaceReign || {},
	log = global.cmnLog,
	cmnMisc = global.cmnMisc,
	cmnSpatial = global.cmnSpatial,
	Vector = cmnSpatial.Vector,
	initialSettings = spaceReign.initialSettings,
	starMap = spaceReign.starMap,
	models = spaceReign.models;
	
	spaceReign.visuals = (function () {
		var winSize,
		viewportSize,
		imgDir,
		imageNames,
		sunTex,
		pinkLoveTex,
		camera = new THREE.PerspectiveCamera(1, 1, 1, 1),
		viewPoint = new THREE.Vector3(0, 0, 0),
		scene = new THREE.Scene(),
		renderer = new THREE.WebGLRenderer({
				antialias : true
			}),
		projector = new THREE.Projector(),
		manageSectorSolars, //stats, sectorGroups = [ new THREE.Object3D() ],
		finalSector = {
			x : initialSettings.sectorCount.x - 1,
			y : initialSettings.sectorCount.y - 1
		};
		
		renderer.sortObjects = false;
		camera = undefined;
		
		imgDir = '../Images/';
		sunTex = THREE.ImageUtils.loadTexture(imgDir + 'sun.png');
		pinkLoveTex = THREE.ImageUtils.loadTexture(imgDir + 'pink_love.png');
		
		manageSectorSolars = (function () {
			var sides = { // the sides of the viewed rectangle of sectors
				from : { // the start sector (inclusive)
					x : 0,
					y : 0
				},
				to : { // the end sector (exclusive)
					x : 0,
					y : 0
				}
			},
			sectors = [];
			
			function renderRowOfSectorModels(bag) {
				var x,
				y,
				j,
				arr = [],
				sectorModel,
				solsDataArray,
				solModel;
				
				// Iterate the visible sectors.
				y = Math.floor(bag.startY);
				for (x = Math.floor(bag.startX); x < bag.xEnd; x++) {
					sectorModel = new THREE.Object3D();
					
					// Get data about the stars in the sector.
					solsDataArray = starMap.space[x][y];
					
					// Iterate the stars.
					for (j = 0; j < solsDataArray.length; j++) {
						// Create the model of a star and add to the sector model.
						solModel = models.createSolarModel(solsDataArray[j]);
						sectorModel.add(solModel);
					}
					
					// Draw the sector's struts.
					sectorModel.add(models.createSectorStrutsModel());
					
					// Move the whole sector into position.
					sectorModel.position.set(x, y, 0);
					
					// Add the sector to my array and the THREE scene.
					arr.push(sectorModel);
					scene.add(sectorModel);
				}
				return arr;
			}
			
			// Remember: this will add to the end in order, but
			// add to the beginning in reverse order.
			function addSectorRows(bag) {
				var i,
				row;
				
				bag.xEnd = bag.startX + bag.fullWidth;
				
				// Add sector rows.
				for (i = 0; i < bag.addSize; i++) {
					row = renderRowOfSectorModels(bag);
					if (bag.atBeginning) {
						sectors.unshift(row);
					} else {
						sectors.push(row);
					}
					bag.startY++;
				}
			}
			
			// This will always add in order, at either end.
			function addSectorColumns(bag) {
				var i,
				cols;
				
				bag.xEnd = bag.startX + bag.addSize;
				
				// Add columns to each sector row.
				for (i = 0; i < sectors.length; i++) {
					cols = renderRowOfSectorModels(bag);
					if (bag.atBeginning) {
						sectors[i] = cols.concat(sectors[i]);
					} else {
						sectors[i] = sectors[i].concat(cols);
					}
					bag.startY++;
				}
			}
			
			function addSectors(newSides) {
				var bag = {}; // bits and gubbins
				
				// Add sectors to the left.
				bag.addSize = sides.from.x - newSides.from.x;
				if (bag.addSize > 0) {
					bag.startX = newSides.from.x;
					bag.startY = newSides.from.y;
					bag.atBeginning = true;
					addSectorColumns(bag);
				}
				
				// Add sectors to the right.
				bag.addSize = newSides.to.x - sides.to.x;
				if (bag.addSize > 0) {
					bag.startX = sides.to.x;
					bag.startY = newSides.from.y;
					bag.atBeginning = false;
					addSectorColumns(bag);
				}
				
				bag.fullWidth = newSides.to.x - newSides.from.x;
				
				// Add sectors to the bottom.
				bag.addSize = sides.from.y - newSides.from.y;
				if (bag.addSize > 0) {
					bag.startX = newSides.from.x;
					bag.startY = newSides.from.y;
					bag.atBeginning = true;
					addSectorRows(bag);
				}
				
				// Add sectors to the top. (y > 0)
				bag.addSize = newSides.to.y - sides.to.y;
				if (bag.addSize > 0) {
					bag.startX = newSides.from.x;
					bag.startY = sides.to.y;
					bag.atBeginning = false;
					addSectorRows(bag);
				}
			}
			
			function removeArrayOfSectors(arr) {
				var i;
				for (i = 0; i < arr.length; i++) {
					scene.remove(arr[i]);
				}
			}
			
			function removeSectorRows(index, removeHeight) {
				var i,
				rows;
				
				if (removeHeight <= 0) {
					return;
				}
				
				// Remove sector rows.
				rows = sectors.splice(index, removeHeight);
				for (i = 0; i < rows.length; i++) {
					removeArrayOfSectors(rows[i]);
				}
			}
			
			function removeSectorColumns(index, removeWidth) {
				var i,
				cols;
				
				if (removeWidth <= 0) {
					return;
				}
				
				// Remove sector columns from each row.
				for (i = 0; i < sectors.length; i++) {
					cols = sectors[i].splice(index, removeWidth);
					removeArrayOfSectors(cols);
				}
			}
			
			function removeSectors(newSides) {
				var removeSize;
				
				// Remove sectors as necessary.
				removeSize = newSides.from.y - sides.from.y;
				removeSectorRows(0, removeSize);
				
				removeSize = sides.to.y - newSides.to.y;
				removeSectorRows(-removeSize, removeSize);
				
				removeSize = newSides.from.x - sides.from.x;
				removeSectorColumns(0, removeSize);
				
				removeSize = sides.to.x - newSides.to.x;
				removeSectorColumns(-removeSize, removeSize);
			}
			
			function determineSides() {
				var r;
				
				if (camera) {
					r = cmnSpatial.sidesAtDepthWithinBounds(projector, camera, finalSector);
					r.to.x++;
					r.to.y++;
					return r;
				}
				
				return cmnMisc.clone(sides);
			}
			
			function assignSceneSectors() {
				var newSides = determineSides();
				removeSectors(newSides);
				addSectors(newSides);
				sides = newSides;
			}
			
			function init() {
				var newSides = determineSides();
				addSectors(newSides);
				sides = newSides;
			}
			
			return {
				init : init,
				assignSceneSectors : assignSceneSectors,
				sectors : sectors
			};
		}
			());
		
		function init() {
			var i,
			$window = $(window);
			
			winSize = {
				x : $window.width(),
				y : $window.height()
			};
			
			// Add dots down the z axis.
			/*for (i = -10; i <= 20; i += 0.1) {
			if (i < 0 || i > 1) {
			scene.add(models.createSolarModel({
			radius : 0.01,
			coord : {
			x : 0,
			y : 0,
			z : i
			}
			}));
			}
			}*/
			
			// Load the solars of each sector into the rendering engine.
			manageSectorSolars.init();
		}
		
		function resize() {
			var $starChartDiv,
			viewAngle,
			aspect,
			near,
			far,
			$window = $(window);
			
			winSize = {
				x : $window.width(),
				y : $window.height()
			};
			
			viewAngle = 96;
			aspect = winSize.x / winSize.y;
			near = 0.5;
			far = 2;
			
			scene.remove(camera);
			camera = new THREE.PerspectiveCamera(viewAngle, aspect, near, far);
			camera.position.x = 0.5;
			camera.position.y = 0.5;
			camera.position.z = 1.8;
			scene.add(camera);
			
			renderer.setSize(winSize.x, winSize.y);
			renderer.domElement.id = 'viewport';
			
			$starChartDiv = $('#viewportDiv');
			$starChartDiv.append(renderer.domElement);
			viewportSize = {
				x : $starChartDiv.width(),
				y : $starChartDiv.height() - 6 //cmn: annoying that this is the only way I know to fix the screen to space coordinates bug.
			};
		}
		
		function render() {
			TWEEN.update();
			
			//            camera.position.x += (mouseX - camera.position.x) * 0.05;
			//            camera.position.y += (-mouseY - camera.position.y) * 0.05;
			// camera.position.x = 0.5;
			// camera.position.y = 0.5;
			
			// Always look down the z-axis (to mimic 1-point perspective).
			viewPoint.x = camera.position.x;
			viewPoint.y = camera.position.y;
			camera.lookAt(viewPoint);
			
			//            group.rotation.x += 0.01;
			//            group.rotation.y += 0.02;
			
			renderer.render(scene, camera);
		}
		
		/*function plotStars() {
		var leftStart,
		rightEnd,
		topStart,
		bottomEnd,
		leftOffset,
		topOffset,
		groupCount = 0,
		xar,
		ix,
		yar,
		iy,
		sar,
		is,
		sol,
		depthScaled,
		depthNormalized,
		particle;
		
		leftStart = Math.floor(viewpos.x);
		rightEnd = Math.ceil((viewpos.x + renderer.domElement.width) / starMap.sectorSize.x);
		topStart = Math.floor(viewpos.y / starMap.sectorSize.y);
		bottomEnd = Math.ceil((viewpos.y + renderer.domElement.height) / starMap.sectorSize.y);
		
		// Iterate horizonally across visible sector.
		xar = starMap.space;
		for (ix = leftStart; ix < rightEnd; ix++) {
		leftOffset = viewpos.x - (ix * starMap.sectorSize.x);
		
		// Iterate vertically across visible sector.
		yar = xar[ix];
		for (iy = topStart; iy < bottomEnd; iy++) {
		topOffset = viewpos.y - (iy * starMap.sectorSize.y);
		
		// Iterate all solars in a sector.
		sar = yar[iy];
		for (is = 0; is < sar.length; is++) {
		sol = sar[is];
		
		particle = new THREE.Particle(
		new THREE.ParticleCanvasMaterial({
		color : Math.random() * 0x808008 + 0x808080,
		solarShader : solarShader
		}));
		particle.position.x = Math.random() * 2000 - 1000;
		particle.position.y = Math.random() * 2000 - 1000;
		particle.position.z = Math.random() * 2000 - 1000;
		particle.scale.x = particle.scale.y = Math.random() * 10 + 5;
		scene.add(particle);
		
		//                        sp = scene.Sprite(imageNames[0], starsLayer);
		//                        //sp.transformOrigin(sp.w / 2, sp.h / 2);
		//                        // sp.offset(-(sp.w/2), -(sp.h/2));
		//                        sp.move(sol.coord.x - leftOffset, sol.coord.y - topOffset);
		//                        //var ax = rand.nextRangedInt(scene.w);
		//                        //var ay = rand.nextRangedInt(scene.h);
		//                        //sp.move(ax, ay);
		//                        //sp.rotate(Math.PI / 4);
		//                        depthScaled = sol.coord.z / starMap.sectorHalfSize.z;
		//                        depthNormalized = ((depthScaled - 1) * initialSettings.defZoom) + 1;
		//                        sp.scale(depthNormalized);
		//                        //sp.setOpacity(0.8);
		//                        sp.update();
		}
		groupCount++;
		}
		}
		}*/
		
		function draw() {
			// var sp = scene.Sprite('sun.png');
			// sp.size(55, 30);
			// sp.update();
			// sp.offset(50, 50);
			// sp.move(100, 100);
			// sp.rotate(3.14 / 4);
			// sp.scale(2);
			// sp.setOpacity(0.8);
			// sp.update();
			
			//plotStars();
			manageSectorSolars.assignSceneSectors();
			render();
			//stats.update();
		}
		
		function moveCamera(screenFrom, screenTo) {
			var xDist,
			yDist,
			fromPoint,
			toPoint;
			
			fromPoint = cmnSpatial.screenPosToCoordsAtDepth(screenFrom, 1, viewportSize, projector, camera);
			toPoint = cmnSpatial.screenPosToCoordsAtDepth(screenTo, 1, viewportSize, projector, camera);
			
			xDist = fromPoint.x - toPoint.x;
			yDist = fromPoint.y - toPoint.y;
			
			camera.position.x += xDist;
			camera.position.y += yDist;
		}
		
		function getObjectsInScreenRegion(screenPos, size) {
			var foundObjects,
			firstSector,
			lastSector,
			lineBottomLeft,
			lineTopRight,
			sectorBackCoord,
			sectorFrontCoord,
			someCoordBL,
			someCoordTR,
			space = starMap.space,
			column,
			sector,
			sol,
			solCoord,
			cx,
			cy,
			i;
			
			function pickLeast(a, b) {
				return Math.floor(Math.min(a, b));
			}
			
			function pickMost(a, b) {
				return Math.floor(Math.max(a, b));
			}
			
			// Get the near-far coordinate pairs of the bottom-left and top-right lines of the region.
			// For each pair get the coordinates of the line going from the camera (minimum depth) at
			// the passed in screen position to the same position but at maximum depth.
			lineBottomLeft = cmnSpatial.screenPosToNearFarCoords({
					x : screenPos.x - size,
					y : screenPos.y + size
				}, viewportSize, projector, camera);
			
			lineTopRight = cmnSpatial.screenPosToNearFarCoords({
					x : screenPos.x + size,
					y : screenPos.y - size
				}, viewportSize, projector, camera);
			
			/*/
			cmn : Put a box showing the hit region.
			scene.add(function () {
				var bln = cmnSpatial.rationNearFarToDepth(lineBottomLeft.near, lineBottomLeft.far, 1),
				blf = cmnSpatial.rationNearFarToDepth(lineBottomLeft.near, lineBottomLeft.far, 0),
				trn = cmnSpatial.rationNearFarToDepth(lineTopRight.near, lineTopRight.far, 1),
				trf = cmnSpatial.rationNearFarToDepth(lineTopRight.near, lineTopRight.far, 0);
				
				return models.createBox(
					[[bln.x, bln.y, bln.z], [bln.x, trn.y, bln.z], [trn.x, trn.y, trn.z], [trn.x, bln.y, bln.z]],
					[[blf.x, blf.y, blf.z], [blf.x, trf.y, blf.z], [trf.x, trf.y, trf.z], [trf.x, blf.y, blf.z]]);
			}
				());
			//cmn*/
			
			// Find which sectors intersect with the screen region.
			lineBottomLeft.sectorBackCoord = cmnSpatial.rationNearFarToDepth(lineBottomLeft.far, lineBottomLeft.near, 0);
			lineBottomLeft.sectorFrontCoord = cmnSpatial.rationNearFarToDepth(lineBottomLeft.far, lineBottomLeft.near, 1);
			firstSector = {
				x : pickLeast(lineBottomLeft.sectorBackCoord.x, lineBottomLeft.sectorFrontCoord.x),
				y : pickLeast(lineBottomLeft.sectorBackCoord.y, lineBottomLeft.sectorFrontCoord.y)
			};
			
			lineTopRight.sectorBackCoord = cmnSpatial.rationNearFarToDepth(lineTopRight.far, lineTopRight.near, 0);
			lineTopRight.sectorFrontCoord = cmnSpatial.rationNearFarToDepth(lineTopRight.far, lineTopRight.near, 1);
			lastSector = {
				x : pickMost(lineTopRight.sectorBackCoord.x, lineTopRight.sectorFrontCoord.x),
				y : pickMost(lineTopRight.sectorBackCoord.y, lineTopRight.sectorFrontCoord.y)
			};
			
			// Fix sector indexes that are out of bounds.
			firstSector = {
				x : pickMost(0, firstSector.x),
				y : pickMost(0, firstSector.y)
			};
			
			lastSector = {
				x : pickLeast(finalSector.x, lastSector.x),
				y : pickLeast(finalSector.y, lastSector.y)
			};
			
			// A list of collided objects.
			foundObjects = [];
			
			// Collision test all chosen sectors.
			for (cx = firstSector.x; cx <= lastSector.x; cx++) {
				column = space[cx];
				for (cy = firstSector.y; cy <= lastSector.y; cy++) {
					sector = column[cy];
					// Collision test all solars in the sector.
					for (i = 0; i < sector.length; i++) {
						sol = sector[i];
						
						// Promote the solar coordinates from sector space to star map space.
						solCoord = {
							x : sol.coord.x + cx,
							y : sol.coord.y + cy,
							z : sol.coord.z // z isn't used here, but it is sent out of this function.
						};
						
						// Get the region's bottom-left coord at the solar's depth.
						someCoordBL = cmnSpatial.rationNearFarToDepth(lineBottomLeft.far, lineBottomLeft.near, sol.coord.z);
						// Is it within the bottom and left?
						if (solCoord.x > someCoordBL.x && solCoord.y > someCoordBL.y) {
							// Get the region's top-right coord at the solar's depth.
							someCoordTR = cmnSpatial.rationNearFarToDepth(lineTopRight.far, lineTopRight.near, sol.coord.z);
							// Is it within the top and right?
							if (solCoord.x < someCoordTR.x && solCoord.y < someCoordTR.y) {
								// The object is within the region.
								foundObjects.push({
									obj : sol,
									objCoord : solCoord,
									sectorCoord : {
										x : cx,
										y : cy
									}
								});
							}
						}
					}
				}
			}
			
			return foundObjects;
		}
		
		return {
			init : init,
			resize : resize,
			moveCamera : moveCamera,
			imageNames : imageNames,
			draw : draw,
			getObjectsInScreenRegion : getObjectsInScreenRegion
		};
	}
		());
	
}
	(this));
