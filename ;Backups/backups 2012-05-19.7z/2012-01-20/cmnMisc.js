"use strict";
String.prototype.format = function() {
	var args = arguments;
	return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function(m, n) {
		if(m == "{{") {
			return "{";
		}
		if(m == "}}") {
			return "}";
		}
		return args[n];
	});
};
function padder(padFunc, str, size, chr) {
	if(chr == undefined)
		chr = ' ';
	var s = str;
	for(var i = s.length; i < size; i++) {
		s = padFunc(s, chr);
	}
	return s;
};

String.prototype.padLeft = function(size, chr) {
	var padFunc = function(str, chr) {
		return chr + str;
	};
	return padder(padFunc, this, size, chr);
};
String.prototype.padRight = function(size, chr) {
	var padFunc = function(str, chr) {
		return str + chr;
	};
	return padder(padFunc, this, size, chr);
};
Array.prototype.insert = function(index, item) {
	this.splice(index, 0, item);
};
Array.prototype.remove = function(index) {
	this.splice(index, 1);
};
// Return 'i' constrained to the specified bounds.
function withinBounds(i, min, max) {
	if(i > max)
		return max;
	else if(i < min)
		return min;
	else
		return i;
};

function spanMilliseconds(startTime/*Date*/, endTime/*Date*/) {
	var startMills = startTime.getTime();
	var endMills = endTime.getTime();
	var retval = endMills - startMills;
	return retval;
};

function spanMilliStr5(startTime/*DateTime*/, endTime/*DateTime*/) {
	var mills = generalUse.spanMilliseconds(startTime, endTime);
	return mills.toString().padLeft(5);
};

function postToUrl(path, params, target) {
	var form = document.createElement("form");
	form.setAttribute("method", "post");
	form.setAttribute("action", path);
	form.setAttribute("style", "display:none");
	if(target) {
		form.setAttribute("target", target);
	}

	for(var key in params) {
		var hiddenField = document.createElement("input");
		hiddenField.setAttribute("type", "hidden");
		hiddenField.setAttribute("name", key);
		hiddenField.setAttribute("value", params[key]);
		form.appendChild(hiddenField);
	}

	document.body.appendChild(form);
	form.submit();
	document.body.removeChild(form);
};

function getFrameDocument(frameId) {
	var d1 = document.getElementById(frameId);
	var d2 = (d1.contentWindow || d1.contentDocument);
	if(d2.document)
		d2 = d2.document;
	return d2;
};

var PageQueryClass = function(q) {
	if(q.length > 1 && q[0] == "?") {
		this.q = q.substring(1, q.length);
	} else {
		this.q = null;
	}

	this.keyValuePairs = new Array();
	if(q) {
		for(var i = 0; i < this.q.split("&").length; i++) {
			this.keyValuePairs[i] = this.q.split("&")[i];
		}
	}

	this.getKeyValuePairs = function() {
		return this.keyValuePairs;
	};

	this.getRawValue = function(key) {
		for(var j = 0; j < this.keyValuePairs.length; j++) {
			if(this.keyValuePairs[j].split("=")[0] == key)
				return this.keyValuePairs[j].split("=")[1];
		}
		return false;
	};

	this.getValue = function(key) {
		return unescape(this.getRawValue(key));
	};

	this.getParameters = function() {
		var a = new Array(this.getLength());
		for(var j = 0; j < this.keyValuePairs.length; j++) {
			a[j] = this.keyValuePairs[j].split("=")[0];
		}
		return a;
	};

	this.getLength = function() {
		return this.keyValuePairs.length;
	};
};
var maxInt32 = Math.pow(2, 31);
var rand = (function() {
	return {
		// Get a random float less than 1, positive.
		randFloat : function() {
			return Math.random();
		},
		// Get a random float in range: 0 <= result < high.
		randRangedFloat : function(high) {
			return Math.random() * high;
		},
		// Get a random integer in range: 0 <= result < high.
		randRangedInt : function(high) {
			return Math.floor(Math.random() * high);
		},
		// Get a random integer (32-bit signed, positive only).
		randInt32 : function() {
			return Math.floor(Math.random() * maxInt32);
		},
		// Get a random boolean.
		randBool : function() {
			return Math.random() >= 0.5;
		}
	};
})();
