"use strict";
// A game inspired by the Amiga game: Supremacy. (and Megalomania, The Settlers, Elite...)
// Codename: Reign
// Proposed Title: Space Reign
// Nasher
var main = (function() {
	var _sunPix = 'sun.png';
	var _imageNames = [_sunPix];

	var _scene;
	var _bgLayer;
	var _starsLayer;

	var _winWidth;
	var _winHeight;
	var _viewLocation = new Vector(0, 0);
	var _viewZoom = 1;

	var drawStars = (function() {
		return {
			go : function() {
				var leftStart = _viewLocation.x / g_starMap.sectorSize.x;
				var rightEnd = (_viewLocation.x + _winWidth) / g_starMap.sectorSize.x;
				var topStart = _viewLocation.y / g_starMap.sectorSize.y;
				var bottomEnd = (_viewLocation.y + _winHeight) / g_starMap.sectorSize.y;
				var xar = g_starMap.space;
				for(var ix = leftStart; ix < rightEnd; ix++)
				{
					var yar = xar[ix];
					for(var iy = topStart; iy < bottomEnd; iy++)
					{
						var sar = yar[iy];
						for(var is = 0; is < sar.length; is++) {
							var sol = sar[is];
							var sp = _scene.Sprite(_sunPix, _starsLayer);
							//sp.transformOrigin(sp.w / 2, sp.h / 2);
							// sp.offset(-(sp.w/2), -(sp.h/2));
							sp.move(sol.coord.x, sol.coord.y);
							//var ax = rand.randRangedInt(_winWidth);
							//var ay = rand.randRangedInt(_winHeight);
							//sp.move(ax, ay);
							//sp.rotate(Math.PI / 4);
							var depthScaled = sol.coord.z / g_starMap.sectorHalfSize.z;
							var depthNormalized = ((depthScaled - 1) * g_initialSettings.defZoom) + 1;
							sp.scale(depthNormalized);
							//sp.setOpacity(0.8);
							sp.update();
						}
					}
				}
			}
		};
	})();

	function runGame() {
		var bg = _scene.Sprite(false, _bgLayer);
		//bg.position(0, 600-32);
		bg.size(_winWidth, _winHeight);
		bg.setColor('#000');

		function frameUpdate() {
			try {
				bg.update();
				// var sp = scene.Sprite('sun.png');
				// sp.size(55, 30);
				// sp.update();
				// sp.offset(50, 50);
				// sp.move(100, 100);
				// sp.rotate(3.14 / 4);
				// sp.scale(2);
				// sp.setOpacity(0.8);
				// sp.update();
				_starsLayer.clear();
				drawStars.go();
				g_vessels.iterateTask();
			} catch(ex) {
				alert("Crash due to: " + ex);
			}

			// if(ticker.currentTick % 30 == 0) {
			// result.innerHTML = 'system load ' + ticker.load + '%';
			// }
		};

		var ticker = _scene.Ticker(frameUpdate);
		ticker.run();
	};

	function initGame() {
		try {
			_winWidth = $(window).width();
			_winHeight = $(window).height();
			// Create the scene object.
			// Draw using the HTML5 canvas element.
			_scene = sjs.Scene({
				w : _winWidth,
				h : _winHeight,
				useCanvas : true
			});
			_bgLayer = _scene.Layer('bg layer');
			_starsLayer = _scene.Layer('stars layer');
			// Load the images in parallel and run the game once loaded.
			_scene.loadImages(_imageNames, runGame);
		} catch(ex) {
			alert("Exception in main begin: " + ex);
		}
	};

	function begin() {
		initGame();
	};

	function resized() {
		_scene.remove();
		initGame();
	};

	return {
		begin : begin,
		resized : resized
	};
})();
$(document).ready(main.begin);
$(window).resize(main.resized);
