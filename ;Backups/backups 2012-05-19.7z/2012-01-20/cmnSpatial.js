"use strict";
var Bounds = function(l, r, t, b) {
	this.left = l;
	this.right = r;
	this.top = t;
	this.bottom = b;
};
Bounds.prototype.width = function() {
	this.right - this.left;
};
Bounds.prototype.height = function() {
	this.bottom - this.top;
};
// A vector type.
var Vector = (function() {
	function vectorMath(mathFunc, first, second) {
		if( second instanceof Vector)
			return new v(mathFunc(first.x, second.x), mathFunc(first.y, second.y), mathFunc(first.z, second.z));

		throw "vectorMath";
	};

	var v = function(x, y, z) {
		this.x = x;
		this.y = y;
		this.z = (z == undefined || z == NaN) ? 0 : z;
	};
	v.prototype.add = function(other) {
		var mathFunc = function(t, o) {
			return t + o;
		};
		return vectorMath(mathFunc, this, other);
	};
	v.prototype.sub = function(other) {
		var mathFunc = function(t, o) {
			return t - o;
		};
		return vectorMath(mathFunc, this, other);
	};
	v.prototype.mul = function(other) {
		var mathFunc = function(t, o) {
			return t * o;
		};
		return vectorMath(mathFunc, this, other);
	};
	v.prototype.div = function(other) {
		var mathFunc = function(t, o) {
			return t / o;
		};
		return vectorMath(mathFunc, this, other);
	};
	v.prototype.length = function() {
		return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
	};
	return v;
})();
// Make a random point within a volume. (integer)
rand.randVectorFloat = function(area/*Vector*/) {
	var x = rand.randRangedFloat(area.x);
	var y = rand.randRangedFloat(area.y);
	var z = rand.randRangedFloat(area.z);
	return new Vector(x, y, z);
};
// Make a random point within a volume. (integer)
rand.randVectorInt = function(area/*Vector*/) {
	var x = rand.randRangedInt(area.x);
	var y = rand.randRangedInt(area.y);
	var z = rand.randRangedInt(area.z);
	return new Vector(x, y, z);
};
var spatial = (function() {
	// The viewport resolution.
	var _viewport = new Vector(1, 1);
	var _viewportHalf = new Vector(1, 1);
	var _v2 = new Vector(2, 2);

	return {
		viewport : function(newViewport) {
			if(newViewport != undefined) {
				if(!( newViewport instanceof Vector))
					throw "new viewport not Vector";
				_viewport = newViewport;
				_viewportHalf = newViewport.div(_v2);
			}
			return _viewport;
		},
		// Half of the viewport resolution.
		viewportHalf : function() {
			return _viewportHalf;
		},
		// Compare vectors using predetermined precedence.
		compare : function(first, second) {
			if( first instanceof Vector && second instanceof Vector) {
				if(first.Z < second.Z)
					return -1;
				if(first.Z > second.Z)
					return 1;
			}
			if(first.Y < second.Y)
				return -1;
			if(first.Y > second.Y)
				return 1;
			if(first.X < second.X)
				return -1;
			if(first.X > second.X)
				return 1;
			return 0;
		},
		// Returns true if the coord is within the topRight to bottomLeft bounds.
		coordIsWithin : function(topLeft, bottomRight, coord) {
			return coord.X >= topLeft.X && coord.Y >= topLeft.Y && coord.X < bottomRight.X && coord.Y < bottomRight.Y;
		}
	};
})();
