"use strict";
// A holacre is a standard cube unit of measure for interstella shipments.
var TradeItem = function(itemName) {
	this.name = itemName;
	// How much the solar system will pay for a holacre of the goods.
	this.importPrice = 0;
	// How much the solar system sells a holacre of the goods for.
	this.exportPrice = 0;
	// How many of the goods the solar system currently has.
	// (In holacres, as a rough estimate. Can be negative, meaning in heavy demand.)
	this.quantity = 0;
};
var TradeGoods = {
	// Define the names of the trade items.
	TradeItemNames : ["Gem-stones", "Food", "Water", "Oil", "Flish"],

	GetIndexByName : function(itemName) {
		return this.TradeItemNames.indexOf(itemName);
	}
};

var Solar = function(solarName) {
	// Solar system name. If undefined then will be randomly generated. The seed comes from the "coord" value.
	this.name = solarName;
	// 3D vector coordinates of the star. (Absolute and NOT relative to a sector.)
	this.coord = Vector.Empty;
	// If the solar system is occupied.
	this.inhabited = false;
	// Information about trade items.
	this.tradeItems = [];
};
// A type of vessel.
var ShipClass = function(shipName, shipSpeed) {
	this.name = shipName;
	this.speed = shipSpeed;
};
// Metrics of an actual vessel.
var Vessel = function(shipClassIndex, shipCoord, shipDest) {
	// The index in the ship classes array.
	this.classIndex = shipClassIndex;
	this.coord = shipCoord;
	this.dest = shipDest;
	// If the ship is at it's destination.
	this.arrived = false;
};
