"use strict";

var g_initialSettings = (function() {
	var _timeMarginFraction = 0.2;

	return {
		epsilon : 0.01,

		// Set a margin that the Governor tries to keep processing time within desired frame rate.
		timeMarginMultiplier : 1.0 - _timeMarginFraction,
		minMarginFraction : 0.01,

		// Used in Governor to determine when to update workload proportions.
		numItersToWait : 5,

		// Average number of stars in the universe.
		numberOfSolarSystems : 40000,

		initialNumberOfShips : 600,

		sectorSize : 500.0,
		sectorDepth : 1000.0,
		sectorCountHorizontal : 80,
		sectorCountVertical : 48,

		maxZoom : 0.01,
		minZoom : 2.0,
		defZoom : 0.25,

		fov : Math.PI * (1.0 - 1.0 / 2.0),
		zNearest : 1.0,
		zFurthest : 100000.0,

		framesPerSecond : 30,
	};
})();

// Space is made up of sectors of solar systems.
var g_starMap = (function() {
	var v2 = new Vector(2, 2, 2);
	var _sectorSize; {
		var size = g_initialSettings.sectorSize;
		var depth = g_initialSettings.sectorDepth;
		_sectorSize = new Vector(size, size, depth);
	}
	var _sectorHalfSize = _sectorSize.div(v2);
	var _sectorCount = new Vector(g_initialSettings.sectorCountHorizontal, g_initialSettings.sectorCountVertical);
	var _size = _sectorSize.mul(_sectorCount);
	var _halfSize = _size.div(v2);

	// // Propagate the star map with solar systems.
	// var universe = [ for i in 1..g_initialSettings.NumberOfSolarSystems -> Solar.CreateSolar <| (rand.Random(m_Size), rand) ]
	//
	// // A function to pull all the stars out of a sector of the universe.
	// var getSolarsWithin (offX:int) (offY:int) =
	// var topLeft = new Vector(m_SectorSize.x * float32 offX, m_SectorSize.y * float32 offY)
	// //var bottomRight = sectorSize + topLeft |> fun s -> {FlatPoint.x = s.x; y = s.y}
	// var bottomRight = new Vector(m_SectorSize.x + topLeft.x, m_SectorSize.y + topLeft.y)
	// var isWithin = fun c ->
	// Spatial.CoordIsWithin(topLeft, bottomRight, c)
	// {   solars =
	// universe
	// |> List.choose (fun s -> if isWithin s.coord then Some(s) else None)
	// |> List.sortWith (fun s1 s2 -> Spatial.Compare(s1.coord,s2.coord))
	// }
	//
	// // Create the star map of sectors.
	// var v = Array2D.init m_SectorCount.x m_SectorCount.y getSolarsWithin
	//
	// v

	var numberOfSectors = _sectorCount.x * _sectorCount.y;
	var averageStarsPerSector = g_initialSettings.numberOfSolarSystems / numberOfSectors;
	var margin = Math.max(1, averageStarsPerSector / 10);
	var minStarsPerSector = Math.max(0, averageStarsPerSector - margin);
	var maxStarsPerSector = averageStarsPerSector + margin;
	var rangeStarsPerSector = maxStarsPerSector - minStarsPerSector + 1;

	// This creates a solar system within the specified area.
	var createSolar = function(area/*Vector*/) {
		var makeTradeItem = function() {
			var ti = new TradeItem();
			ti.ImportPrice = rand.randInt32();
			ti.ExportPrice = rand.randInt32();
			ti.Quantity = rand.randInt32();
			return ti;
		};
		var sol = new Solar();
		sol.coord = area;
		sol.inhabited = rand.randBool();
		for(var i = 0; i < TradeGoods.TradeItemNames.length; i++) {
			sol.tradeItems.push(makeTradeItem());
		}
		return sol;
	};
	var createSolarWithin = function(topLeft/*Vector*/, bottomRight/*Vector*/) {
		return createSolar(rand.randVectorFloat(bottomRight.sub(topLeft)).add(topLeft));
	};
	// Create stars in a sector of the universe.
	var createSectorSolars = function(offX, offY) {
		var topLeft = new Vector(_sectorSize.x * offX, _sectorSize.y * offY, 0.0);
		var bottomRight = new Vector(topLeft.x + _sectorSize.x, topLeft.y + _sectorSize.y, _size.z);
		var numSolars = minStarsPerSector + rand.randRangedInt(rangeStarsPerSector);
		var sols = [];
		for(var i = 1; i <= numSolars; i++) {
			sols.push(createSolarWithin(topLeft, bottomRight));
		}
		sols.sort(function(s1, s2) {
			return spatial.compare(s1.coord, s2.coord);
		});
		return sols;
	};
	// Create the star map of sectors.
	var _space = [];
	for(var ix = 0; ix < _sectorCount.x; ix++) {
		var ar = [];
		for(var iy = 0; iy < _sectorCount.y; iy++) {
			ar[iy] = createSectorSolars(ix, iy);
		}
		_space[ix] = ar;
	}
	return {
		// Sectors define space as a checker board.
		// The size of a sector as a vector.
		sectorSize : _sectorSize,
		// Half the size of a sector as a vector.
		sectorHalfSize : _sectorHalfSize,
		// How many sectors the star map is divided into, horizontally and vertically.
		// This is also bottom-right back-most point of space.
		sectorCount : _sectorCount,
		// The top-left front-most point of space is zero.
		zero : new Vector(0, 0, 0),
		// This is also bottom-right back-most point of space.
		size : _size,
		// Half the size of the star map.
		halfSize : _halfSize,
		// The star map.
		space : _space
	};
})();
// The types of vessel class available.
var g_shipClasses = (function() {
	var ar = [];
	// Standard ships move by warping space.
	ar.push(new ShipClass('Runt', 1.0));
	ar.push(new ShipClass('Rump', 2.5));
	// This class of ship doesn't move but travels by folding space. (AKA. heighliner)
	ar.push(new ShipClass('Void-folder', 0.0));
	return ar;
})();

var g_vessels = (function() {
	var _allShips = (function() {
		function makeShip() {
			var v2 = new Vector(2, 2);
			function chooseSystem() {
				var sectorCenter = g_starMap.sectorCount.div(v2);
				var solars = g_starMap.space[sectorCenter.x][sectorCenter.y];
				if(solars.length == 0) {
					// A fix for when a sector doesn't have any stars.
					return new Solar();
				}
				return solars[rand.randRangedInt(solars.length)];
			}

			// Now make the Vessel object.
			var classIndex = rand.randRangedInt(g_shipClasses.length);
			var vx = rand.randRangedFloat(g_starMap.sectorSize.x);
			var vy = rand.randRangedFloat(g_starMap.sectorSize.y);
			var coord = g_starMap.size.div(v2).add(new Vector(vx, vy, 0));
			var dest = chooseSystem();
			var ship = new Vessel(classIndex, coord, dest);
			return ship;
		}

		var ar = [];
		for(var i = 0; i < g_initialSettings.initialNumberOfShips; i++) {
			ar.push(makeShip());
		}
		return ar;
	})();

	// This is how far through the ship list "iterateTask" has traversed.
	var _taskStateIndex = 0;

	// Here is the portion that "iterateTask" is allowed process in one calling.
	var _taskPortion = maxInt32;

	return {
		// Return how many jobs "iterateTask" needs to do. (The number of ships currently in transit.)
		taskCount : function() {
			_allShips.length
		},
		// Here is the portion that "iterateTask" is allowed process in one calling.
		taskPortion : _taskPortion,
		allShips : _allShips,
		// This manages the coordination of vessels.
		iterateTask : function() {
			var dilation = _allShips.length / _taskPortion;

			// A function to move a coordinate closer to a destination.
			// Returns the tuple (newCoordinate : DepthPoint, isAtDestination : bool)
			function moveStep(hereCoord, thereCoord, moveDistance) {
				var distCoord = thereCoord.sub(hereCoord);
				var fullDistance = distCoord.length;
				if(moveDistance > fullDistance) {
					// The move distance will over-shoot the target, so just return the destination.
					return {
						coord : thereCoord,
						arrived : true
					};
				}
				var ratio = moveDistance / fullDistance;
				var ratioVector = new Vector(ratio, ratio);
				var result = hereCoord.add(distCoord).mul(ratioVector);
				return {
					coord : result,
					arrived : false
				};
			}

			// A function to move a ship closer to it's destination.
			function moveShip(ship) {
				if(!ship.arrived) {
					var v = moveStep(ship.coord, ship.dest.coord, (g_shipClasses[ship.classIndex].speed * dilation));
					ship.coord = v.coord;
					ship.arrived = v.arrived;
				}
			}

			// Move the allowed portion of ships *that are currently in transit*.
			var startIndex = _taskStateIndex;
			var tuple = (function() {
				var count = _allShips.length;
				var e = -1 + startIndex + (_taskPortion > count ? count : _taskPortion);
				if(e < count) {
					return [e, -1];
				}
				return [count - 1, e - count];
			})();
			var endIndex = tuple[0];
			var extraEndIndex = tuple[1];

			// Here I should be splitting the list into left, middle and right segments
			// and then joining them back after, perhaps.

			// Do the right portion.
			for(var i = startIndex; i <= endIndex; i++) {
				moveShip(_allShips[i]);
			}

			// Do the left portion.
			if(extraEndIndex >= 0) {
				for(var i = 0; i <= extraEndIndex; i++) {
					moveShip(_allShips[i]);
				}
				_taskStateIndex = extraEndIndex + 1;
			} else {
				var s = endIndex + 1;
				_taskStateIndex = (s == _allShips.length) ? 0 : s;
			}
		}
	};
})();
var g_governor = (function() {
	// The task portion allowance, it is the multiplier of each task's total job count.
	// (It will never be greater than 1.0, but always greater than 0.0)
	var _portionMultiplier = 1.0;

	// A count of how many iterations have passed since the last proportioning.
	var _reproportioningCountdown = 0;

	// Set the portion allowance for each task, based on the m_portionMultiplier.
	// Basically there should be a portion field in the module of each task,
	// and this function will alter that number when a new m_portionMultiplier is set.
	function doApportioning() {
		g_vessels.taskPortion = _portionMultiplier * g_vessels.taskCount();
	}

	// Get each task to do it's thing.
	function doTasks() {
		// Move a portion of the vessels.
		g_vessels.iterateTask();

		// Work out how much to divide each task's workload.
		if(_reproportioningCountdown == 0) {
			//var paintTimeAverage = visualizer.PaintTimer.ElapsedMilliseconds / float InitialSettings.NumItersToWait
			//var taskTimeAverage = float taskTimer.ElapsedMilliseconds / float InitialSettings.NumItersToWait
			//visualizer.PaintTimer.Reset()
			//taskTimer.Reset()

			// Reset the counter.
			_reproportioningCountdown = g_initialSettings.numItersToWait;

			// Set a new divisor of portions.
			var _portionMultiplier = (function() {
				// Deduct from "frame rate" the "painting time" to get "allowed processing time".
				var timeAllowance = 1;
				//visualizer.MillisecondsPerFrame - paintTimeAverage

				// Reduce that time by a margin.
				var timeMargin = timeAllowance * g_initialSettings.timeMarginMultiplier;

				//var p = m_portionMultiplier * timeMargin / taskTimeAverage
				var p = timeMargin / 1;
				//taskTimeAverage;

				if(p > 1) {
					//viz.StepUpFps()
					//recomputeFormTimer ()
					return 1;
				} else if(p > 0) {
					return p;
				} else {
					//viz.StepDownFps()
					//recomputeFormTimer ()
					var halfP = _portionMultiplier / 2;
					if(halfP > g_initialSettings.minMarginFraction) {
						return halfP;
					} else {
						return g_initialSettings.minMarginFraction;
					}
				}
			})();
			// Now to set the new portion allowance in all tasks.
			doApportioning();
		} else {
			_reproportioningCountdown--;
		}
	}

	return {
		initialize : function() {
			//taskTimer.Start()
			g_governor.recomputeGameTimings(1);
			//visualizer.FramesPerSecond)
		},
		recomputeGameTimings : function(fps) {
			//visualizer.FramesPerSecond <- fps
		},
		// Manage the tasks.
		iterateTasks : function() {
			// Run all tasks.
			doTasks();
		}
	};
})();
