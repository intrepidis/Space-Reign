﻿/// <reference path="Three.js" />
/// <reference path="Tween.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignSingletons.js" />
/// <reference path="SpaceReignTypes.js" />

(function (global) {
    "use strict";

    var cmnSpatial = global.cmnSpatial,
        Vector = global.cmnSpatial.Vector,
        initialSettings = global.spaceReign.initialSettings;

    function createSunSphere(bag) {
        var steps, end,
            coord, i,
            geometry, material, mesh;

        geometry = new THREE.IcosahedronGeometry();
        material = new THREE.MeshBasicMaterial({
            color: bag.color,
            shading: THREE.FlatShading
        });

        mesh = new THREE.Mesh(geometry, material);
        mesh.scale = bag.scale;
        mesh.position = bag.position;

        steps = [];
        end = bag.stepsOffset + 7;
        for (i = bag.stepsOffset; i < end; i++) {
            coord = { x: bag.xSpeed * i, y: bag.ySpeed * i };
            steps.push(cmnMisc.clone(coord));
        }

        cmnSpatial.tweenLoop(cmnMisc.rand.nextRangedInt(1000) + 3000, mesh.rotation, steps);

        return mesh;
    }

    global.spaceReign.models = (function () {
        function createSolarModel(solData) {
            var group, bag = {};

            bag.scale = new THREE.Vector3(solData.mass, solData.mass, solData.mass);
            bag.position = new THREE.Vector3(solData.coord.x, solData.coord.y, solData.coord.z);

            bag.xSpeed = Math.PI / 1;
            bag.ySpeed = Math.PI / 1.5;

            group = new THREE.Object3D();

            bag.color = 0xFFFF97;
            bag.stepsOffset = 0;
            group.add(createSunSphere(bag));

            bag.color = 0xFFFC00;
            bag.stepsOffset = 0.8;
            group.add(createSunSphere(bag));

            return group;
        }

        function createSectorStrutsModel() {
            var model = new THREE.Object3D(),
                addLine = cmnSpatial.makeAddLineFunc(model),
                sectorSize = initialSettings.sectorSize;

            // Add the x,y axis lines.
            addLine([[0, 1, 1], [0, 0, 1], [1, 0, 1]]);

            // Add the z axis line.
            addLine([[0, 0, 0], [0, 0, 1]]);

            //model.position.set(0, 0, 0);
            model.scale.set(sectorSize, sectorSize, sectorSize);
            return model;
        };

        return {
            createSolarModel: createSolarModel,
            createSectorStrutsModel: createSectorStrutsModel
        };
    } ());

} (this));
