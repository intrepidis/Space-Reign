/// <reference path="Three.js" />
/// <reference path="Tween.js" />
/// <reference path="cmnMisc.js" />
(function (global) {
    "use strict";

    var Vector;

    global.cmnSpatial = global.cmnSpatial || {};
    global.cmnMisc = global.cmnMisc || {};

    global.cmnSpatial.Bounds = function (l, r, t, b) {
        this.left = l;
        this.right = r;
        this.top = t;
        this.bottom = b;
    };
    global.cmnSpatial.Bounds.prototype.width = function () {
        return this.right - this.left;
    };
    global.cmnSpatial.Bounds.prototype.height = function () {
        return this.bottom - this.top;
    };

    // A vector type.
    global.cmnSpatial.Vector = (function () {
        var V = function (x, y, z) {
            this.x = x;
            this.y = y;
            this.z = (z === undefined || isNaN(z)) ? 0 : z;
        };

        function vectorMath(mathFunc, first, second) {
            if (second instanceof V) {
                return new V(mathFunc(first.x, second.x),
                             mathFunc(first.y, second.y),
                             mathFunc(first.z, second.z));
            }

            throw new Error("The argument passed to vector math is an unsupported type.");
        }

        V.prototype.add = function (other) {
            var mathFunc = function (t, o) {
                return t + o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.sub = function (other) {
            var mathFunc = function (t, o) {
                return t - o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.mul = function (other) {
            var mathFunc = function (t, o) {
                return t * o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.div = function (other) {
            var mathFunc = function (t, o) {
                return t / o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.length = function () {
            return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        };

        return V;
    } ());

    Vector = global.cmnSpatial.Vector;

    // Make a random point within a volume. (integer)
    global.cmnMisc.rand.nextVectorFloat = function (area/*Vector*/) {
        var x, y, z;
        x = this.nextRangedFloat(area.x);
        y = this.nextRangedFloat(area.y);
        z = this.nextRangedFloat(area.z);
        return new Vector(x, y, z);
    };

    // Make a random point within a volume. (integer)
    global.cmnMisc.rand.nextVectorInt = function (area/*Vector*/) {
        var x, y, z;
        x = this.nextRangedInt(area.x);
        y = this.nextRangedInt(area.y);
        z = this.nextRangedInt(area.z);
        return new Vector(x, y, z);
    };

    // Compare vectors using predetermined precedence.
    global.cmnSpatial.compare = function (first, second) {
        if (first instanceof Vector && second instanceof Vector) {
            if (first.Z < second.Z) {
                return -1;
            }
            if (first.Z > second.Z) {
                return 1;
            }
        }
        if (first.Y < second.Y) {
            return -1;
        }
        if (first.Y > second.Y) {
            return 1;
        }
        if (first.X < second.X) {
            return -1;
        }
        if (first.X > second.X) {
            return 1;
        }
        return 0;
    };

    // Returns true if the coord is within the topRight to bottomLeft bounds.
    global.cmnSpatial.coordIsWithin = function (topLeft, bottomRight, coord) {
        return coord.X >= topLeft.X
            && coord.Y >= topLeft.Y
            && coord.X < bottomRight.X
            && coord.Y < bottomRight.Y;
    };

    global.cmnSpatial.tweenLoop = function (overalTime, rotationOrPosition, arrayOfCoordinateSteps) {
        var //overalTime
            coord = rotationOrPosition,
            steps = arrayOfCoordinateSteps,
            firstStep = steps[0],
            numTweens = steps.length,
            time = overalTime / (steps.length - 1),
            prop, i, tween, firstTween, prevTween;

        if (steps.length < 2) {
            throw new Error("There should be at least 2 steps.");
        }

        // Put the properties of the first step directly into the coordinate object.
        for (prop in firstStep) {
            coord[prop] = firstStep[prop];
        }

        // Create tweens and chain them.
        tween = firstTween = new TWEEN.Tween(coord);
        tween.to(steps[1], time);
        for (i = 2; i < numTweens; i++) {
            prevTween = tween;

            tween = new TWEEN.Tween(coord);
            tween.to(steps[i], time);

            prevTween.chain(tween);
        }

        // Create the final tween, which instantly jumps back to the beginning.
        prevTween = tween;
        tween = new TWEEN.Tween(coord);
        tween.to(firstStep, 0);
        prevTween.chain(tween);
        tween.chain(firstTween);

        firstTween.start();
    };

    global.cmnSpatial.makeAddLineFunc = function (model) {
        return function addLine(points) {
            var i, p, material, geometry = new THREE.Geometry();
            for (i = 0; i < points.length; i++) {
                p = points[i];
                geometry.vertices.push(new THREE.Vertex(new THREE.Vector3(p[0], p[1], p[2])));
            }
            geometry.computeBoundingSphere();
            material = new THREE.LineBasicMaterial({ color: 0xFF0000, opacity: 1, linewidth: 3 });
            model.add(new THREE.Line(geometry, material));
        };
    };

} (this));
