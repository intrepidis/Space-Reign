/// <reference path="cmnMisc.js" />
/// <reference path="SpaceReignSingletons.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignVisuals.js" />
/// <reference path="SpaceReignControls.js" />
(function (global) {
    "use strict";

    var main,
        //requestAnimationFrame = global.window.requestAnimationFrame,
        visuals = global.spaceReign.visuals,
        controls = global.spaceReign.controls,
        vessels = global.spaceReign.vessels;

    global.spaceReign.log.mouseLogging = true;

    // A game inspired by the Amiga game: Supremacy. (and Megalomania, The Settlers, Elite...)
    // Codename: Space Reign
    // Proposed Title: Galactic Reign
    // By->Nasher
    main = (function () {
        function ticker() {
            requestAnimationFrame(ticker);

            //controls.handleInput();
            visuals.draw();
            vessels.iterateTask();
        }

        function begin() {
            controls.init();
            visuals.init();
            visuals.resize();

            // Load the images in parallel and begin the game ticker once loaded.
            //scene.loadImages(visuals.imageNames, ticker);
            requestAnimationFrame(ticker);
        }

        function resized() {
            visuals.resize();
        }

        return {
            begin: begin,
            resized: resized
        };
    } ());

    $(document).ready(main.begin);
    $(window).resize(main.resized);
} (this));
