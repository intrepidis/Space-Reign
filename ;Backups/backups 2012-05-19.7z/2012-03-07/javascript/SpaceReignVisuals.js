﻿/// <reference path="Three.js" />
/// <reference path="Tween.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignSingletons.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignModels.js" />

(function (global) {
    "use strict";

    var cmnSpatial = global.cmnSpatial,
        Vector = global.cmnSpatial.Vector,
        initialSettings = global.spaceReign.initialSettings,
        starMap = global.spaceReign.starMap,
        models = global.spaceReign.models;

    global.spaceReign.visuals = (function () {
        var viewpos, viewposHalf, v2,
            imgDir, imageNames, sunTex, pinkLoveTex,
            solarShader,
            camera = new THREE.PerspectiveCamera(1, 1, 1, 1),
            scene = new THREE.Scene(),
            renderer = new THREE.WebGLRenderer({ antialias: false }), //stats, sectorGroups = [ new THREE.Object3D() ];
            manageSectorSolars;

        camera = undefined;

        imgDir = '../Images/';
        sunTex = THREE.ImageUtils.loadTexture(imgDir + 'sun.png');
        pinkLoveTex = THREE.ImageUtils.loadTexture(imgDir + 'pink_love.png');

        //============================================================================
        //manageSectorSolars
        //
        manageSectorSolars = (function () {
            var sides = { top: -1, bottom: -1, left: -1, right: -1 },
                tempCount = 0,
                sectors = [[new THREE.Object3D()]];
            sectors = [];

            function instantiateSectors(bag) {
                var x, y, xEnd, j, arr = [], sectorModel,
                    solsDataArray, solData, solModel,
                    geometry, material, mesh,
                    ss = initialSettings.sectorSize, ssh = ss / 2, ssd = ss * 2,
                    st = 10, sth = st / 2,
                    vertices, faces,
                    pushVertex,
                    v1, v2, v3, v4, v5, v6, v7, v8, v9,
                    u = undefined;

                x = bag.startX;
                y = bag.startY;
                xEnd = x + bag.length;
                for (; x < xEnd; x++) {
                    sectorModel = new THREE.Object3D();

                    // Get data about the stars in the sector.
                    solsDataArray = starMap.space[x][y];
                    for (j = 0; j < solsDataArray.length; j++) {
                        // Create the model of a star and add to the sector.
                        solModel = models.createSolarModel(solsDataArray[j]);
                        sectorModel.add(solModel);
                    }

                    // Draw a cube around the sector.
                    material = new THREE.MeshBasicMaterial({
                        color: 0x0077C0,
                        shading: THREE.FlatShading
                    });
                    //geometry = new THREE.TetrahedronGeometry(10);
                    geometry = new THREE.CubeGeometry(ss, ss, ss, u, u, u, material);
                    mesh = new THREE.Mesh(geometry/*, material*/);
                    mesh.position.x = ssh;
                    mesh.position.y = ssh;
                    mesh.position.z = ssh;
                    //sectorModel.add(mesh);
                    //scene.add(mesh);

                    // Draw the sector's struts.
                    material = new THREE.MeshBasicMaterial({
                        //color: 0x0077C0,
                        shading: THREE.FlatShading,
                        wireframe: true,
                        map: pinkLoveTex
                    });
                    //geometry = new THREE.TetrahedronGeometry(ssd);
                    //geometry = new THREE.CubeGeometry(ss, st, st, u, u, u, material);

                    //                    geometry = new THREE.Geometry();
                    //                    pushVertex = function (x, y, z) {
                    //                        var vertex = new THREE.Vertex();
                    //                        vertex.position.x = x;
                    //                        vertex.position.y = y;
                    //                        vertex.position.z = z;
                    //                        geometry.vertices.push(vertex);
                    //                    };
                    //                    pushVertex(0, 0, 0); // left,top,back
                    //                    pushVertex(st, 0, 0); // left+strutThin,top,back
                    //                    pushVertex(0, ss, 0); // left,bottom,back
                    //
                    //                    pushVertex(0, 0, 0); // left,top,back
                    //                    pushVertex(ss, 0, 0); // right,top,back
                    //                    pushVertex(0, st, 0); // left,top+strutThin,back
                    //                    geometry.computeBoundingSphere();
                    //                    vertices = [
                    //		                [2, 2, 2], [1, 0, 2], [0, 2, 0], [2, 0, 0]
                    //	                ];

                    //                    faces = [
                    //		                [2, 1, 0], [0, 3, 2], [1, 3, 0], [2, 3, 1]
                    //	                ];
                    //                    geometry = new THREE.PolyhedronGeometry(vertices, faces, ss * 0.9);



                    //                    geometry = new THREE.Geometry();
                    //                    pushVertex = function (x, y, z) {
                    //                        var vertex = new THREE.Vertex();
                    //                        vertex.position.set(x, y, z);
                    //                        geometry.vertices.push(vertex);
                    //                    };
                    //                    pushVertex(2, 2, 2);
                    //                    pushVertex(1, 0, 2);
                    //                    pushVertex(0, 2, 0);
                    //                    pushVertex(2, 0, 0);
                    //                    pushVertex(2, 1, 0);
                    //                    geometry.computeBoundingSphere();
                    //                    material = new THREE.LineBasicMaterial({ color: 0xFF0000, opacity: 1, linewidth: 3 });
                    //                    mesh = new THREE.Mesh(geometry, material);//new THREE.MeshBasicMaterial({ color: 0xFF0000, wireframe: true, transparent: false }));
                    //                    mesh.position.set(0, 0, 0);
                    //                    mesh.scale.set(100, 100, 100);
                    //                    scene.add(mesh);




                    scene.add(models.createSectorStrutsModel());




                    //                    mesh = (function () {
                    //                        var i, points = [], spline;

                    //                        function addPoint(x, y, z) {
                    //                            
                    //                        }

                    //                        spline = new THREE.Spline(points);

                    //                        for (i = 0; i < points.length * n_sub; i++) {
                    //                            index = i / (points.length * n_sub);
                    //                            position = spline.getPoint(index);

                    //                            geometry.vertices[i] = new THREE.Vertex(new THREE.Vector3(position.x, position.y, position.z));

                    //                            colors[i] = new THREE.Color(0xffffff);
                    //                            colors[i].setHSV(0.6, (200 + position.x) / 400, 1.0);

                    //                            colors2[i] = new THREE.Color(0xffffff);
                    //                            //colors2[ i ].setHSV( 0.1, 1.0, ( 200 + position.x ) / 400 );
                    //                            colors2[i].setHSV(0.9, (200 + position.y) / 400, 1.0);

                    //                            colors3[i] = new THREE.Color(0xffffff);
                    //                            colors3[i].setHSV(i / (points.length * n_sub), 1.0, 1.0);
                    //                        }
                    //                    } ());
                    //                    mesh.position.set(0, 0, 0);
                    //                    mesh.scale.set(100, 100, 100);
                    //                    scene.add(mesh);


                    //                    geometry = new THREE.CubeGeometry(st, st, st, u, u, u, material);
                    //                    mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0xFF0000 }));
                    //                    mesh.position.set(0, 0, 0);
                    //                    scene.add(mesh);

                    //                    geometry = new THREE.CubeGeometry(st, st, st, u, u, u, material);
                    //                    mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0xFFFF00 }));
                    //                    mesh.position.set(ss, 0, 0);
                    //                    scene.add(mesh);

                    //                    geometry = new THREE.CubeGeometry(st, st, st, u, u, u, material);
                    //                    mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x00FF00 }));
                    //                    mesh.position.set(0, ss, 0);
                    //                    scene.add(mesh);

                    //                    geometry = new THREE.CubeGeometry(st, st, st, u, u, u, material);
                    //                    mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x00FFFF }));
                    //                    mesh.position.set(0, 0, ss);
                    //                    scene.add(mesh);

                    //=========================================================
                    //this works
                    //                    scene.add(function () {
                    //                        var shape, geometry, mesh;

                    //                        shape = new THREE.Shape();
                    //                        shape.moveTo(0, 0); // begin path
                    //                        shape.lineTo(ssh, 0);
                    //                        shape.lineTo(st, st);
                    //                        shape.lineTo(0, ssh);
                    //                        shape.lineTo(0, 0); // close path

                    //                        //extrudeSettings = { amount: 4, bevelEnabled: false, bevelSegments: 2, steps: 2, bevelSize: 8, bevelThickness:5 }
                    //                        geometry = shape.extrude({ amount: 1 });

                    //                        //var mesh = THREE.SceneUtils.createMultiMaterialObject(
                    //                        //    geometry, [
                    //                        //        new THREE.MeshBasicMaterial({ color: 0x0077C0 }),
                    //                        //        new THREE.MeshBasicMaterial({ color: 0x000000, wireframe: true, transparent: true })]);
                    //                        //mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x0077C0 }));
                    //                        mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x0077C0, wireframe: true, transparent: true }));
                    //                        mesh.position.z = ss;
                    //                        return mesh;
                    //                    } ());

                    //                    scene.add(function () {
                    //                        var shape, geometry, mesh;

                    //                        shape = new THREE.Shape();
                    //                        shape.moveTo(0, sth); // begin path
                    //                        shape.lineTo(ssh, 0);
                    //                        shape.lineTo(0, -sth);
                    //                        shape.lineTo(0, sth); // close path

                    //                        //extrudeSettings = { amount: 4, bevelEnabled: false, bevelSegments: 2, steps: 2, bevelSize: 8, bevelThickness:5 }
                    //                        geometry = shape.extrude({ amount: 1 });

                    //                        //var mesh = THREE.SceneUtils.createMultiMaterialObject(
                    //                        //    geometry, [
                    //                        //        new THREE.MeshBasicMaterial({ color: 0x0077C0 }),
                    //                        //        new THREE.MeshBasicMaterial({ color: 0x000000, wireframe: true, transparent: true })]);
                    //                        mesh = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({ color: 0x0077C0 }));

                    //                        //mesh.up.set(0, -1, 0);
                    //                        //mesh.lookAt(new THREE.Vector3(1, 1, 0));
                    //                        //mesh.rotation.set(0, Math.PI / 2, Math.PI / 4);
                    //                        mesh.rotation.set(0, Math.PI / 2, 0);
                    //                        mesh.position.set(sth, sth, ss);

                    //                        return mesh;
                    //                    } ());
                    //=========================================================

                    //mesh.rotation.set(rx, ry, rz);
                    //mesh.scale.set(s, s, s);


                    //mesh = new THREE.Mesh(geometry, material);
                    //mesh.rotation.x = Math.PI / 7;
                    //mesh.rotation.y = Math.PI / 5;
                    //mesh.scale = new THREE.Vector3(100, 100, 100);
                    //                    mesh.position.x = ssh;
                    //                    mesh.position.y = sth;
                    //                    mesh.position.z = sth;
                    //sectorModel.add(mesh);
                    //scene.add(mesh);

                    // Add the sector to my array and the THREE scene.
                    arr.push(sectorModel);
                    scene.add(sectorModel);
                }
                return arr;
            }

            function removeArrayOfSectors(arr) {
                var i;
                for (i = 0; i < arr.length; i++) {
                    scene.remove(arr[i]);
                }
            }

            // Remember: this will add to the end in order, but
            // add to the beginning in reverse order.
            function addSectorRows(bag) {
                var addMethod, i, row;

                addMethod = bag.atBeginning ?
                    function (r) { sectors.unshift(r); } :
                    function (r) { sectors.push(r); };

                bag.length = bag.fullWidth;

                // Add sector rows.
                for (i = 0; i < bag.addSize; i++) {
                    row = instantiateSectors(bag);
                    addMethod(row);
                }
            }

            // This will always add in order, at either end.
            function addSectorColumns(bag) {
                var addMethod, i, cols;

                addMethod = bag.atBeginning ?
                        function (a, b) { return b.concat(a); } :
                        function (a, b) { return a.concat(b); };

                bag.length = bag.addSize;

                // Add columns to each sector row.
                for (i = 0; i < sectors.length; i++) {
                    cols = instantiateSectors(bag);
                    sectors[i] = addMethod(sectors[i], cols);
                }
            }

            function addSectors(newSides) {
                var bag = {};

                // Add sectors to the left.
                bag.addSize = sides.left - newSides.left;
                if (bag.addSize > 0) {
                    bag.startX = newSides.left;
                    bag.startY = newSides.top;
                    bag.atBeginning = true;
                    addSectorColumns(bag);
                }

                // Add sectors to the right.
                bag.addSize = newSides.right - sides.right;
                if (bag.addSize > 0) {
                    bag.startX = newSides.right - (bag.addSize - 1);
                    bag.startY = newSides.top;
                    bag.atBeginning = false;
                    addSectorColumns(bag);
                }

                bag.fullWidth = newSides.right - newSides.left + 1;

                bag.addSize = sides.top - newSides.top;
                if (bag.addSize > 0) {
                    bag.atBeginning = true;
                    addSectorRows(bag);
                }

                bag.addSize = newSides.bottom - sides.bottom;
                if (bag.addSize > 0) {
                    bag.atBeginning = false;
                    addSectorRows(bag);
                }
            }

            function removeSectorRows(index, removeHeight) {
                var i, rows;

                if (removeHeight <= 0) {
                    return;
                }

                // Remove sector rows.
                rows = sectors.splice(index, removeHeight);
                for (i = 0; i < rows.length; i++) {
                    removeArrayOfSectors(rows[i]);
                }
            }

            function removeSectorColumns(index, removeWidth) {
                var i, cols;

                if (removeWidth <= 0) {
                    return;
                }

                // Remove sector columns from each row.
                for (i = 0; i < sectors.length; i++) {
                    cols = sectors[i].splice(index, removeWidth);
                    removeArrayOfSectors(cols);
                }
            }

            function removeSectors(newSides) {
                var removeSize;

                // Remove sectors as necessary.
                removeSize = newSides.top - sides.top;
                removeSectorRows(0, removeSize);

                removeSize = sides.bottom - newSides.bottom;
                removeSectorRows(-removeSize, removeSize);

                removeSize = newSides.left - sides.left;
                removeSectorColumns(0, removeSize);

                removeSize = sides.right - newSides.right;
                removeSectorColumns(-removeSize, removeSize);
            }

            function determineSides() {
                var t, b;
                if (sides.top === -1) {
                    t = 0;
                    b = 2;
                } else if (++tempCount % 27 === 0) {
                    t = 1 - sides.top; // toggle between 0 & 1
                    b = 5 - sides.bottom; // toggle between 2 & 3
                } else {
                    t = sides.top;
                    b = sides.bottom;
                }
                //camera.position.z += 10;
                return { top: t, bottom: b, left: 0, right: 3 };
            }

            function assignSceneSectors() {
                var newSides = determineSides();
                removeSectors(newSides);
                addSectors(newSides);
                sides = newSides;
            }

            function init() {
                var newSides = determineSides();
                addSectors(newSides);
                sides = newSides;
            }

            return {
                init: init,
                assignSceneSectors: assignSceneSectors
            };
        } ());
        //
        //manageSectorSolars
        //============================================================================

        function init() {
            // The viewpos resolution.
            viewpos = new Vector(1, 1);
            viewposHalf = new Vector(1, 1);
            v2 = new Vector(2, 2);

            //scene.add(models.createSolarModel(6));

            // Load the solars of each sector into the rendering engine.
            manageSectorSolars.init();
        }

        function resize() {
            var starChartDiv,
                winWidth = $(window).width(),
                winHeight = $(window).height(),
                viewAngle, aspect, near, far;

            viewAngle = 75;
            aspect = winWidth / winHeight;
            near = 1;
            far = 10000;

            scene.remove(camera);
            camera = new THREE.PerspectiveCamera(viewAngle, aspect, near, far);
            camera.position.z = 1000;
            scene.add(camera);

            renderer.setSize(winWidth, winHeight);
            starChartDiv = $('#star-chart').get(0);
            starChartDiv.appendChild(renderer.domElement);
        }

        function render() {
            var viewPoint = scene.position;

            TWEEN.update();

            //            camera.position.x += (mouseX - camera.position.x) * 0.05;
            //            camera.position.y += (-mouseY - camera.position.y) * 0.05;
            camera.position.x = 200;
            camera.position.y = 200;

            // Always look down the z-axis (to mimic 1-point perspective).
            viewPoint.x = camera.position.x;
            viewPoint.y = camera.position.y;
            camera.lookAt(viewPoint);

            //            group.rotation.x += 0.01;
            //            group.rotation.y += 0.02;

            renderer.render(scene, camera);
        }

        function viewposGetSet(newViewport) {
            if (newViewport !== undefined) {
                if (!(newViewport instanceof Vector)) {
                    throw new Error("The new view port position argument should be of Vector type.");
                }
                viewpos = newViewport;
                viewposHalf = newViewport.div(v2);
            }
            return viewpos;
        }

        // Half of the viewpos resolution.
        function viewposHalfGet() {
            return viewposHalf;
        }

        //=====================================================NEWLINE        // plotStarsNEWLINE        //NEWLINE        //        function plotStars() {NEWLINE        //            var leftStart, rightEnd, topStart, bottomEnd,NEWLINE        //                leftOffset, topOffset,NEWLINE        //                groupCount = 0,NEWLINE        //                xar, ix, yar, iy, sar, is,NEWLINE        //                sol, depthScaled, depthNormalized, particle;NEWLINENEWLINE        //            leftStart = Math.floor(viewpos.x / starMap.sectorSize.x);NEWLINE        //            rightEnd = Math.ceil((viewpos.x + renderer.domElement.width) / starMap.sectorSize.x);NEWLINE        //            topStart = Math.floor(viewpos.y / starMap.sectorSize.y);NEWLINE        //            bottomEnd = Math.ceil((viewpos.y + renderer.domElement.height) / starMap.sectorSize.y);NEWLINENEWLINE        //            // Iterate horizonally across visible sector.NEWLINE        //            xar = starMap.space;NEWLINE        //            for (ix = leftStart; ix < rightEnd; ix++) {NEWLINE        //                leftOffset = viewpos.x - (ix * starMap.sectorSize.x);NEWLINENEWLINE        //                // Iterate vertically across visible sector.NEWLINE        //                yar = xar[ix];NEWLINE        //                for (iy = topStart; iy < bottomEnd; iy++) {NEWLINE        //                    topOffset = viewpos.y - (iy * starMap.sectorSize.y);NEWLINENEWLINE        //                    // Iterate all solars in a sector.NEWLINE        //                    sar = yar[iy];NEWLINE        //                    for (is = 0; is < sar.length; is++) {NEWLINE        //                        sol = sar[is];NEWLINENEWLINE        //                        particle = new THREE.Particle(NEWLINE        //                            new THREE.ParticleCanvasMaterial(NEWLINE        //                                { color: Math.random() * 0x808008 + 0x808080,NEWLINE        //                                    solarShader: solarShaderNEWLINE        //                                }));NEWLINE        //                        particle.position.x = Math.random() * 2000 - 1000;NEWLINE        //                        particle.position.y = Math.random() * 2000 - 1000;NEWLINE        //                        particle.position.z = Math.random() * 2000 - 1000;NEWLINE        //                        particle.scale.x = particle.scale.y = Math.random() * 10 + 5;NEWLINE        //                        scene.add(particle);NEWLINENEWLINE        //                        //                        sp = scene.Sprite(imageNames[0], starsLayer);NEWLINE        //                        //                        //sp.transformOrigin(sp.w / 2, sp.h / 2);NEWLINE        //                        //                        // sp.offset(-(sp.w/2), -(sp.h/2));NEWLINE        //                        //                        sp.move(sol.coord.x - leftOffset, sol.coord.y - topOffset);NEWLINE        //                        //                        //var ax = rand.nextRangedInt(scene.w);NEWLINE        //                        //                        //var ay = rand.nextRangedInt(scene.h);NEWLINE        //                        //                        //sp.move(ax, ay);NEWLINE        //                        //                        //sp.rotate(Math.PI / 4);NEWLINE        //                        //                        depthScaled = sol.coord.z / starMap.sectorHalfSize.z;NEWLINE        //                        //                        depthNormalized = ((depthScaled - 1) * initialSettings.defZoom) + 1;NEWLINE        //                        //                        sp.scale(depthNormalized);NEWLINE        //                        //                        //sp.setOpacity(0.8);NEWLINE        //                        //                        sp.update();NEWLINE        //                    }NEWLINE        //                    groupCount++;NEWLINE        //                }NEWLINE        //            }NEWLINE        //        }NEWLINE        //NEWLINE        // plotStarsNEWLINE        //=====================================================

        function draw() {
            // var sp = scene.Sprite('sun.png');
            // sp.size(55, 30);
            // sp.update();
            // sp.offset(50, 50);
            // sp.move(100, 100);
            // sp.rotate(3.14 / 4);
            // sp.scale(2);
            // sp.setOpacity(0.8);
            // sp.update();

            //plotStars();
            manageSectorSolars.assignSceneSectors();
            render();
            //stats.update();
        }

        return {
            init: init,
            resize: resize,
            viewpos: viewposGetSet,
            viewposHalf: viewposHalfGet,
            imageNames: imageNames,
            draw: draw
        };
    } ());

} (this));
