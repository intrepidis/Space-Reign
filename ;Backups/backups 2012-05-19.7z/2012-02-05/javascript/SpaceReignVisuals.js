﻿/// <reference path="sprite.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />
(function (global) {
    "use strict";

    var //$ = global.jQuery,
        Vector = global.Vector,
        initialSettings = global.initialSettings,
        //spatial = global.spatial,
        starMap = global.starMap;

    global.visuals = (function () {
        var viewpos, viewposHalf, v2,
            imgDir, imageNames, scene,
            bgLayer, starsLayer, bg;

        imgDir = '../Images/';
        imageNames = [imgDir + 'sun.png'];

        function init(inScene) {
            scene = inScene;

            // The viewpos resolution.
            viewpos = new Vector(1, 1);
            viewposHalf = new Vector(1, 1);
            v2 = new Vector(2, 2);

            bgLayer = scene.Layer('bgLayer');
            starsLayer = scene.Layer('starsLayer'/*, { parent: $('#starChart').get(0) }*/);

            bg = scene.Sprite(false, bgLayer);
            //bg.position(0, 600-32);
            bg.size(scene.w, scene.h);
            bg.setColor('#000');
        }

        function viewposGetSet(newViewport) {
            if (newViewport !== undefined) {
                if (!(newViewport instanceof Vector)) {
                    throw "new viewpos not Vector";
                }
                viewpos = newViewport;
                viewposHalf = newViewport.div(v2);
            }
            return viewpos;
        }

        // Half of the viewpos resolution.
        function viewposHalfGet() {
            return viewposHalf;
        }

        function drawStars() {
            var leftStart, rightEnd, topStart, bottomEnd,
                leftOffset, topOffset,
                xar, ix, yar, iy, sar, is,
                sol, sp, depthScaled, depthNormalized;

            leftStart = Math.floor(viewpos.x / starMap.sectorSize.x);
            rightEnd = Math.ceil((viewpos.x + scene.w) / starMap.sectorSize.x);
            topStart = Math.floor(viewpos.y / starMap.sectorSize.y);
            bottomEnd = Math.ceil((viewpos.y + scene.h) / starMap.sectorSize.y);

            // Iterate horizonally across visible sector.
            xar = starMap.space;
            for (ix = leftStart; ix < rightEnd; ix++) {
                leftOffset = viewpos.x - (ix * starMap.sectorSize.x);

                // Iterate vertically across visible sector.
                yar = xar[ix];
                for (iy = topStart; iy < bottomEnd; iy++) {
                    topOffset = viewpos.y - (iy * starMap.sectorSize.y);

                    // Iterate all solars in a sector.
                    sar = yar[iy];
                    for (is = 0; is < sar.length; is++) {

                        sol = sar[is];
                        sp = scene.Sprite(imageNames[0], starsLayer);
                        //sp.transformOrigin(sp.w / 2, sp.h / 2);
                        // sp.offset(-(sp.w/2), -(sp.h/2));
                        sp.move(sol.coord.x - leftOffset, sol.coord.y - topOffset);
                        //var ax = rand.nextRangedInt(scene.w);
                        //var ay = rand.nextRangedInt(scene.h);
                        //sp.move(ax, ay);
                        //sp.rotate(Math.PI / 4);
                        depthScaled = sol.coord.z / starMap.sectorHalfSize.z;
                        depthNormalized = ((depthScaled - 1) * initialSettings.defZoom) + 1;
                        sp.scale(depthNormalized);
                        //sp.setOpacity(0.8);
                        sp.update();
                    }
                }
            }
        }

        function draw() {
            bg.update();

            // var sp = scene.Sprite('sun.png');
            // sp.size(55, 30);
            // sp.update();
            // sp.offset(50, 50);
            // sp.move(100, 100);
            // sp.rotate(3.14 / 4);
            // sp.scale(2);
            // sp.setOpacity(0.8);
            // sp.update();

            starsLayer.clear();
            drawStars();
        }

        return {
            init: init,
            viewpos: viewposGetSet,
            viewposHalf: viewposHalfGet,
            imageNames: imageNames,
            draw: draw
        };
    } ());

} (this));
