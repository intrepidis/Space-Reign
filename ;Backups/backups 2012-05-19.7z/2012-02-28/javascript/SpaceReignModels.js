﻿/// <reference path="Three.js" />
/// <reference path="Tween.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />

(function (global) {
    "use strict";

    var cmnSpatial = global.cmnSpatial,
        Vector = global.cmnSpatial.Vector,
        initialSettings = global.spaceReign.initialSettings;

    global.spaceReign.models = (function () {
        function addSolToScene(scene) {
            //#1
            //            var particle = new THREE.Particle(
            //                new THREE.ParticleBasicMaterial({
            //                    color: Math.random() * 0x808008 + 0x808080,
            //                    size: 5,
            //                    sizeAttenuation: true,
            //                    map: sprite,
            //                    depthTest: false
            //                }));
            //            particle.position.x = 0;
            //            particle.position.y = 0;
            //            particle.position.z = 0;
            //            particle.scale.x = particle.scale.y = 50;
            //            particle.name = "my sol";
            //            scene.add(particle);
            //#2
            //var particleCount = 5,
            //    particles = new THREE.Geometry(),
            //    pMaterial =
            //        new THREE.ParticleBasicMaterial({
            //            color: 0xF0D000,
            //            size: 50,
            //            sizeAttenuation: true,
            //            map: sunImg,
            //            blend: THREE.MultiplyBlending,
            //            depthTest: true
            //        });
            //
            //for (var p = 0; p < particleCount; p++) {
            //    var pX = Math.random() * 10 - 5,
            //        pY = Math.random() * 10 - 5,
            //        pZ = Math.random() * 10 - 5,
            //        particle =
            //            new THREE.Vertex(
            //                new THREE.Vector3(pX, pY, pZ)
            //            );
            //
            //    particles.vertices.push(particle);
            //}
            //
            //var particleSystem =
            //    new THREE.ParticleSystem(
            //        particles,
            //        pMaterial);
            //
            //scene.add(particleSystem);

            var scale = 70,
                pi = function (scale) { return Math.PI * scale; };

            function addSunSphere(colour, stepsBeginIndex) {
                var steps, stepsEndIndex,
                    xSpeed, ySpeed, coord, i,
                    geometry, material, mesh;

                stepsEndIndex = stepsBeginIndex + 7;
                xSpeed = Math.PI / 1;
                ySpeed = Math.PI / 1.5;

                geometry = new THREE.IcosahedronGeometry();
                material = new THREE.MeshLambertMaterial({
                    color: colour,
                    shading: THREE.FlatShading
                });
                mesh = new THREE.Mesh(geometry, material);

                mesh.scale = new THREE.Vector3(scale, scale, scale);
                scene.add(mesh);

                steps = [];
                for (i = stepsBeginIndex; i < stepsEndIndex; i++) {
                    coord = { x: xSpeed * i, y: ySpeed * i };
                    steps.push(cmnMisc.clone(coord));
                }

                cmnSpatial.tweenLoop(12000, mesh.rotation, steps);
                mesh.position.z = 2000;
                //cmnSpatial.tweenLoop(4000, mesh.position, [
                //    { z: 0 },
                //    { z: -800 },
                //    { z: 0 },
                //    { z: 6000 },
                //    { z: 0}]);
            }

            addSunSphere(0xFFFF97, 0);
            addSunSphere(0xFFFC00, 0.8);

            var pointLight = new THREE.PointLight(0xFFFFFF);
            pointLight.position.x = -scale;
            pointLight.position.y = -scale;
            pointLight.position.z = scale;
            scene.add(pointLight);

            var pointLight = new THREE.PointLight(0xFFFFFF);
            pointLight.position.x = scale;
            pointLight.position.y = scale;
            pointLight.position.z = scale;
            scene.add(pointLight);
        }

        return {
            addSolToScene: addSolToScene
        };
    } ());

} (this));
