(function (global) {
	"use strict";
	
	var spaceReign = global.spaceReign = global.spaceReign || {},
	cmnSpatial = global.cmnSpatial,
	Vector = cmnSpatial.Vector;
	
	// A holacre is a standard cube unit of measure for interstella shipments.
	spaceReign.TradeItem = function (itemName) {
		// Name of the goods.
		this.name = itemName;
		// How much the solar system will pay for a holacre of the goods.
		this.importPrice = 0;
		// How much the solar system sells a holacre of the goods for.
		this.exportPrice = 0;
		// How many of the goods the solar system currently has.
		// (In holacres, as a rough estimate. Can be negative, meaning in heavy demand.)
		this.quantity = 0;
	};
	
	spaceReign.Solar = function (solarName) {
		// Solar system name. If undefined then will be randomly generated. The seed comes from the "coord" value.
		this.name = solarName;
		// 3D vector coordinates of the star. (Relative to a sector, NOT absolute space coordinates.)
		this.coord = Vector.Empty;
		// If the solar system is occupied.
		this.inhabited = false;
		// Size of the solar system.
		this.radius = 0.02;
		// Information about trade items.
		this.tradeItems = [];
	};
	
	// A type of vessel.
	spaceReign.ShipClass = function (name, speed) {
		this.name = name;
		this.speed = speed;
	};
	
	// Metrics of an actual vessel.
	spaceReign.Vessel = function (shipName, shipClassIndex, shipCoord, shipDest) {
		this.name = shipName;
		// The index in the ship classes array.
		this.classIndex = shipClassIndex;
		this.coord = shipCoord;
		this.dest = shipDest;
		// If the ship is at it's destination.
		this.arrived = false;
	};
	spaceReign.Vessel.prototype = {
		changeName : function (newName) {
			this.name = newName;
		}
	};
}
	(this));
