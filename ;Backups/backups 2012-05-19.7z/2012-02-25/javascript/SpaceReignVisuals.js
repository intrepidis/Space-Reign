﻿/// <reference path="Three.js" />
/// <reference path="Tween.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignModels.js" />

(function (global) {
    "use strict";

    var cmnSpatial = global.cmnSpatial,
        Vector = global.cmnSpatial.Vector,
        initialSettings = global.spaceReign.initialSettings,
        starMap = global.spaceReign.starMap,
        models = global.spaceReign.models;

    global.spaceReign.visuals = (function () {
        var viewpos, viewposHalf, v2,
            imgDir, imageNames, sunImg,
            solarShader,
            camera = new THREE.PerspectiveCamera(1, 1, 1, 1),
            scene = new THREE.Scene(),
            renderer = new THREE.WebGLRenderer({ antialias: false }), //stats, sectorGroups = [ new THREE.Object3D() ];
            manageSectorSolars;

        camera = undefined;

        //var ambientLight = new THREE.AmbientLight(0x202020);
        //scene.add(ambientLight);

        imgDir = '../Images/';
        imageNames = [imgDir + 'sun.png'];
        sunImg = THREE.ImageUtils.loadTexture(imgDir + 'sun.png');

        solarShader = function (context) {
            context.beginPath();
            context.arc(0, 0, 1, 0, Math.PI2, true);
            context.closePath();
            context.fill();
        };

        manageSectorSolars = (function () {
            var sides = { top: -1, bottom: -1, left: -1, right: -1 },
                tempCount = 0,
                sectors = [[new THREE.Object3D()]];
            sectors = [];

            function createArrayOfSectors(length) {
                var i, particle, arr = [];
                for (i = 0; i < length; i++) {
                    particle = new THREE.Particle(
                        new THREE.ParticleBasicMaterial({
                            color: 0xF0D000,
                            size: 50,
                            sizeAttenuation: true,
                            map: sunImg,
                            blend: THREE.MultiplyBlending,
                            depthTest: true
                        }));
                    particle.position.x = Math.random() * 20 - 10;
                    particle.position.y = Math.random() * 20 - 10;
                    particle.position.z = Math.random() * 20 - 10;
                    particle.scale.x = particle.scale.y = Math.random() * 10 + 5;
                    particle.name =
                        "px:{0},py:{1},pz:{2},s:{3}".format(
                            Math.floor(particle.position.x),
                            Math.floor(particle.position.y),
                            Math.floor(particle.position.z),
                            Math.floor(particle.scale.x)
                        );
                    arr.push(particle);
                    scene.add(particle);
                }
                return arr;
            }

            function removeArrayOfSectors(arr) {
                var i;
                for (i = 0; i < arr.length; i++) {
                    scene.remove(arr[i]);
                }
            }

            // Remember: this will add to the end in order, but
            // add to the beginning in reverse order.
            function addSectorRows(atBeginning, addHeight, fullWidth) {
                var addMethod, i, row;

                if (addHeight <= 0) {
                    return;
                }

                addMethod = atBeginning ?
                    function (r) { sectors.unshift(r); } :
                    function (r) { sectors.push(r); };

                // Add sector rows.
                for (i = 0; i < addHeight; i++) {
                    row = createArrayOfSectors(fullWidth);
                    addMethod(row);
                }
            }

            // This will always add in order, at either end.
            function addSectorColumns(atBeginning, addWidth) {
                var addMethod, i, cols;

                if (addWidth <= 0) {
                    return;
                }

                addMethod = atBeginning ?
                        function (a, b) { return b.concat(a); } :
                        function (a, b) { return a.concat(b); };

                // Add columns to each sector row.
                for (i = 0; i < sectors.length; i++) {
                    cols = createArrayOfSectors(addWidth);
                    sectors[i] = addMethod(sectors[i], cols);
                }
            }

            function addSectors(newSides) {
                var addSize, fullWidth;

                // Add new sectors.
                addSize = sides.left - newSides.left;
                addSectorColumns(true, addSize);

                addSize = newSides.right - sides.right;
                addSectorColumns(false, addSize);

                fullWidth = newSides.right - newSides.left + 1;

                addSize = sides.top - newSides.top;
                addSectorRows(true, addSize, fullWidth);

                addSize = newSides.bottom - sides.bottom;
                addSectorRows(false, addSize, fullWidth);
            }

            function removeSectorRows(index, removeHeight) {
                var i, rows;

                if (removeHeight <= 0) {
                    return;
                }

                // Remove sector rows.
                rows = sectors.splice(index, removeHeight);
                for (i = 0; i < rows.length; i++) {
                    removeArrayOfSectors(rows[i]);
                }
            }

            function removeSectorColumns(index, removeWidth) {
                var i, cols;

                if (removeWidth <= 0) {
                    return;
                }

                // Remove sector columns from each row.
                for (i = 0; i < sectors.length; i++) {
                    cols = sectors[i].splice(index, removeWidth);
                    removeArrayOfSectors(cols);
                }
            }

            function removeSectors(newSides) {
                var removeSize;

                // Remove sectors as necessary.
                removeSize = newSides.top - sides.top;
                removeSectorRows(0, removeSize);

                removeSize = sides.bottom - newSides.bottom;
                removeSectorRows(-removeSize, removeSize);

                removeSize = newSides.left - sides.left;
                removeSectorColumns(0, removeSize);

                removeSize = sides.right - newSides.right;
                removeSectorColumns(-removeSize, removeSize);
            }

            function determineSides() {
                var t, b;
                if (sides.top === -1) {
                    t = 0;
                    b = 2;
                } else if (++tempCount % 27 === 0) {
                    t = 1 - sides.top; // toggle between 0 & 1
                    b = 5 - sides.bottom; // toggle between 2 & 3
                } else {
                    t = sides.top;
                    b = sides.bottom;
                }
                camera.position.z += 10;
                return { top: t, bottom: b, left: 0, right: 3 };
            }

            function assignSceneSectors() {
                var newSides = determineSides();
                removeSectors(newSides);
                addSectors(newSides);
                sides = newSides;
            }

            function init() {
                var newSides = determineSides();
                addSectors(newSides);
                sides = newSides;
            }

            return {
                init: init,
                assignSceneSectors: assignSceneSectors
            };
        } ());

        function init() {
            // The viewpos resolution.
            viewpos = new Vector(1, 1);
            viewposHalf = new Vector(1, 1);
            v2 = new Vector(2, 2);

            models.addSolToScene(scene);

            // Load the solars of each sector into the rendering engine.
            //manageSectorSolars.init();

            //stats = new Stats();
            //stats.domElement.style.position = 'absolute';
            //stats.domElement.style.top = '0px';
            //starChartDiv.appendChild(stats.domElement);
        }

        function resize() {
            var starChartDiv,
                winWidth = $(window).width(),
                winHeight = $(window).height(),
                viewAngle, aspect, near, far;

            viewAngle = 75;
            aspect = winWidth / winHeight;
            near = 1;
            far = 10000;

            scene.remove(camera);
            camera = new THREE.PerspectiveCamera(viewAngle, aspect, near, far);
            camera.position.z = -1000;
            scene.add(camera);

            renderer.setSize(winWidth, winHeight);
            starChartDiv = $('#star-chart').get(0);
            starChartDiv.appendChild(renderer.domElement);
        }

        function render() {
            TWEEN.update();

            //            camera.position.x += (mouseX - camera.position.x) * 0.05;
            //            camera.position.y += (-mouseY - camera.position.y) * 0.05;
            camera.lookAt(scene.position);

            //            group.rotation.x += 0.01;
            //            group.rotation.y += 0.02;

            renderer.render(scene, camera);
        }

        function viewposGetSet(newViewport) {
            if (newViewport !== undefined) {
                if (!(newViewport instanceof Vector)) {
                    throw new Error("The new view port position argument should be of Vector type.");
                }
                viewpos = newViewport;
                viewposHalf = newViewport.div(v2);
            }
            return viewpos;
        }

        // Half of the viewpos resolution.
        function viewposHalfGet() {
            return viewposHalf;
        }

        function plotStars() {
            var leftStart, rightEnd, topStart, bottomEnd,
                leftOffset, topOffset,
                groupCount = 0,
                xar, ix, yar, iy, sar, is,
                sol, depthScaled, depthNormalized, particle;

            leftStart = Math.floor(viewpos.x / starMap.sectorSize.x);
            rightEnd = Math.ceil((viewpos.x + renderer.domElement.width) / starMap.sectorSize.x);
            topStart = Math.floor(viewpos.y / starMap.sectorSize.y);
            bottomEnd = Math.ceil((viewpos.y + renderer.domElement.height) / starMap.sectorSize.y);

            // Iterate horizonally across visible sector.
            xar = starMap.space;
            for (ix = leftStart; ix < rightEnd; ix++) {
                leftOffset = viewpos.x - (ix * starMap.sectorSize.x);

                // Iterate vertically across visible sector.
                yar = xar[ix];
                for (iy = topStart; iy < bottomEnd; iy++) {
                    topOffset = viewpos.y - (iy * starMap.sectorSize.y);

                    // Iterate all solars in a sector.
                    sar = yar[iy];
                    for (is = 0; is < sar.length; is++) {
                        sol = sar[is];

                        particle = new THREE.Particle(
                            new THREE.ParticleCanvasMaterial(
                                { color: Math.random() * 0x808008 + 0x808080,
                                    solarShader: solarShader
                                }));
                        particle.position.x = Math.random() * 2000 - 1000;
                        particle.position.y = Math.random() * 2000 - 1000;
                        particle.position.z = Math.random() * 2000 - 1000;
                        particle.scale.x = particle.scale.y = Math.random() * 10 + 5;
                        scene.add(particle);

                        //                        sp = scene.Sprite(imageNames[0], starsLayer);
                        //                        //sp.transformOrigin(sp.w / 2, sp.h / 2);
                        //                        // sp.offset(-(sp.w/2), -(sp.h/2));
                        //                        sp.move(sol.coord.x - leftOffset, sol.coord.y - topOffset);
                        //                        //var ax = rand.nextRangedInt(scene.w);
                        //                        //var ay = rand.nextRangedInt(scene.h);
                        //                        //sp.move(ax, ay);
                        //                        //sp.rotate(Math.PI / 4);
                        //                        depthScaled = sol.coord.z / starMap.sectorHalfSize.z;
                        //                        depthNormalized = ((depthScaled - 1) * initialSettings.defZoom) + 1;
                        //                        sp.scale(depthNormalized);
                        //                        //sp.setOpacity(0.8);
                        //                        sp.update();
                    }
                    groupCount++;
                }
            }
        }

        function draw() {
            // var sp = scene.Sprite('sun.png');
            // sp.size(55, 30);
            // sp.update();
            // sp.offset(50, 50);
            // sp.move(100, 100);
            // sp.rotate(3.14 / 4);
            // sp.scale(2);
            // sp.setOpacity(0.8);
            // sp.update();

            //plotStars();
            //manageSectorSolars.assignSceneSectors();
            render();
            //stats.update();
        }

        return {
            init: init,
            resize: resize,
            viewpos: viewposGetSet,
            viewposHalf: viewposHalfGet,
            imageNames: imageNames,
            draw: draw
        };
    } ());

} (this));
