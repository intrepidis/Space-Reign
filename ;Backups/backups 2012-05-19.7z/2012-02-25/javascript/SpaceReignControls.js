/// <reference path="cmnMisc.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignVisuals.js" />
//reign = reign || {};
(function (global) {
    "use strict";

    var Vector = global.cmnSpatial.Vector,
        visuals = global.spaceReign.visuals,
        starMap = global.spaceReign.starMap,
        log = global.spaceReign.log;

    global.spaceReign.controls = (function () {
        var mouseDownPosition, mouseIsDragging, mousePrev, mouseDragThreshold = 3;

        function logMouse(name, value) {
            if (log.mouseLogging) {
                log.addVar(name, value);
            }
        }

        function captureMousePrev() {
            mousePrev = {
                //down: input.mouse.down,
                //position: new Vector(input.mouse.position.x, input.mouse.position.y)
            };
            logMouse('mousePrev', mousePrev);
        }

        function onDocumentMouseMove(event) {
            //mouseX = event.clientX - windowHalfX;
            //mouseY = event.clientY - windowHalfY;
        }

        function onDocumentTouchStart(event) {
            if (event.touches.length === 1) {
                event.preventDefault();

                //mouseX = event.touches[ 0 ].pageX - windowHalfX;
                //mouseY = event.touches[ 0 ].pageY - windowHalfY;
            }
        }

        function onDocumentTouchMove(event) {
            if (event.touches.length === 1) {
                event.preventDefault();

                //mouseX = event.touches[ 0 ].pageX - windowHalfX;
                //mouseY = event.touches[ 0 ].pageY - windowHalfY;
            }
        }

        function init() {
            // When the mouse button is pressed the mouse position is stored here.
            mouseDownPosition = new Vector(0, 0);
            mouseIsDragging = false;
            captureMousePrev();

            document.addEventListener('mousemove', onDocumentMouseMove, false);
            document.addEventListener('touchstart', onDocumentTouchStart, false);
            document.addEventListener('touchmove', onDocumentTouchMove, false);
        }

        function mouseClicked() {
            logMouse('MOUSE', 'CLICKED');

            var d = $('#solar-dialog')
                .load('../markup/dialogs.html #solar')
			    .dialog({
			        autoOpen: false,
			        title: 'poo bums',
			        width: 500,
			        height: 300
			    });

            d.dialog('open');
        }

        function handleInput() {
            var mousePosVector, mouseThisDist, mouseDragLength;

            //mousePosVector = new Vector(input.mouse.position.x, input.mouse.position.y);
            mousePosVector = new Vector(0, 0);
            mouseThisDist = (function () {
                //TODO: make this "lazy" again.
                return mousePrev.position.sub(mousePosVector);
            } ());

            //logMouse('input.mouse', input.mouse);
            logMouse('mousePrev', mousePrev);

//            if (!input.mouse.down) {
//                if (!mouseIsDragging && mousePrev.down) {
//                    // A click occurred.
//                    mouseClicked();
//                }

//                mouseIsDragging = false;
//            } else {
//                if (!mousePrev.down) {
//                    mouseDownPosition = mousePosVector;
//                }

//                if (!mouseIsDragging) {
//                    // then see if there was a click or the start of a drag.
//                    mouseDragLength = (function () {
//                        var val, nowMousePos;
//                        nowMousePos = mousePosVector;
//                        val = mouseDownPosition.sub(nowMousePos);
//                        return val.length();
//                    } ());

//                    if (mouseDragLength > mouseDragThreshold) {
//                        // Started dragging the screen.
//                        mouseIsDragging = true;
//                    }
//                }
//            }

//            logMouse('mouseDownPosition', mouseDownPosition);
//            logMouse('mouseIsDragging', mouseIsDragging);

//            if (mouseIsDragging) {
//                (function () {
//                    var xDist, yDist, newX, newY, prePos = visuals.viewpos();

//                    if (input.mouse.down) {
//                        xDist = mousePrev.position.x - mousePosVector.x;
//                        yDist = mousePrev.position.y - mousePosVector.y;

//                        newX = prePos.x + xDist;
//                        newY = prePos.y + yDist;
//                    } else {
//                        newX = prePos.x;
//                        newY = prePos.y;
//                    }

//                    function changeViewPos(newX, newY) {
//                        var x, y;
//                        x = global.cmnMisc.withinBounds(newX, 0, starMap.size.x);
//                        y = global.cmnMisc.withinBounds(newY, 0, starMap.size.y);
//                        visuals.viewpos(new Vector(x, y));
//                    }
//                    changeViewPos(newX, newY);
//                } ());
//            }

            captureMousePrev();
        }

        return {
            init: init,
            handleInput: handleInput
        };
    } ());
} (this));
