/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />

this.spaceReign = this.spaceReign || {};

(function (global) {
    "use strict";

    var Vector = global.cmnSpatial.Vector;

    // A holacre is a standard cube unit of measure for interstella shipments.
    global.spaceReign.TradeItem = function (itemName) {
        // Name of the goods.
        this.name = itemName;
        // How much the solar system will pay for a holacre of the goods.
        this.importPrice = 0;
        // How much the solar system sells a holacre of the goods for.
        this.exportPrice = 0;
        // How many of the goods the solar system currently has.
        // (In holacres, as a rough estimate. Can be negative, meaning in heavy demand.)
        this.quantity = 0;
    };

    global.spaceReign.TradeGoods = {
        // Define the names of the trade items.
        TradeItemNames: ["Gem-stones", "Food", "Water", "Oil", "Flish"],

        GetIndexByName: function (itemName) {
            return this.TradeItemNames.indexOf(itemName);
        }
    };

    global.spaceReign.Solar = function (solarName) {
        // Solar system name. If undefined then will be randomly generated. The seed comes from the "coord" value.
        this.name = solarName;
        // 3D vector coordinates of the star. (Relative to a sector, NOT absolute space coordinates.)
        this.coord = Vector.Empty;
        // If the solar system is occupied.
        this.inhabited = false;
        // Information about trade items.
        this.tradeItems = [];
    };

    // A type of vessel.
    global.spaceReign.ShipClass = function (shipName, shipSpeed) {
        this.name = shipName;
        this.speed = shipSpeed;
    };

    // Metrics of an actual vessel.
    global.spaceReign.Vessel = function (shipClassIndex, shipCoord, shipDest) {
        // The index in the ship classes array.
        this.classIndex = shipClassIndex;
        this.coord = shipCoord;
        this.dest = shipDest;
        // If the ship is at it's destination.
        this.arrived = false;
    };
} (this));
