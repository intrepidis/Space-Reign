(function (global) {
    "use strict";

    // Extra methods for arrays.
    Array.prototype.insert = function (index, item) {
        this.splice(index, 0, item);
    };

    Array.prototype.remove = function (index) {
        this.splice(index, 1);
    };

    // Extra methods for strings.
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/\{\{|\}\}|\{(\d+)\}/g, function (m, n) {
            if (m === "{{") {
                return "{";
            }
            if (m === "}}") {
                return "}";
            }
            return args[n];
        });
    };

    function padder(padFunc, str, size, chr) {
        var i, s = str;

        if (chr === undefined) {
            chr = ' ';
        }
        for (i = s.length; i < size; i++) {
            s = padFunc(s, chr);
        }
        return s;
    }

    String.prototype.padLeft = function (size, chr) {
        var padFunc = function (str, chr) {
            return chr + str;
        };
        return padder(padFunc, this, size, chr);
    };

    String.prototype.padRight = function (size, chr) {
        var padFunc = function (str, chr) {
            return str + chr;
        };
        return padder(padFunc, this, size, chr);
    };

    // Return 'i' constrained to the specified bounds.
    global.withinBounds = function (i, min, max) {
        if (i > max) {
            return max;
        } else if (i < min) {
            return min;
        } else {
            return i;
        }
    };

    global.spanMilliseconds = function (startTime/*Date*/, endTime/*Date*/) {
        var startMills, endMills, retval;
        startMills = startTime.getTime();
        endMills = endTime.getTime();
        retval = endMills - startMills;
        return retval;
    };

    global.spanMilliStr5 = function (startTime/*DateTime*/, endTime/*DateTime*/) {
        var mills, retval;
        mills = global.spanMilliseconds(startTime, endTime);
        retval = mills.toString().padLeft(5);
        return retval;
    };

    /*begin jslint ignore*/
    global.postToUrl = function (path, params, target) {
        var form, key, hiddenField;

        form = document.createElement("form");
        form.setAttribute("method", "post");
        form.setAttribute("action", path);
        form.setAttribute("style", "display:none");
        if (target) {
            form.setAttribute("target", target);
        }

        for (key in params) {
            hiddenField = document.createElement("input");
            hiddenField.setAttribute("type", "hidden");
            hiddenField.setAttribute("name", key);
            hiddenField.setAttribute("value", params[key]);
            form.appendChild(hiddenField);
        }

        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    };
    /*end jslint ignore*/

    /*begin jslint ignore*/
    global.getFrameDocument = function (frameId) {
        var d1, d2;
        d1 = document.getElementById(frameId);
        d2 = (d1.contentWindow || d1.contentDocument);
        if (d2.document) {
            d2 = d2.document;
        }
        return d2;
    };
    /*end jslint ignore*/

    /*begin jslint ignore*/
    global.PageQueryClass = function (q) {
        var i;

        if (q.length > 1 && q[0] == "?") {
            this.q = q.substring(1, q.length);
        } else {
            this.q = null;
        }

        this.keyValuePairs = new Array();
        if (q) {
            for (i = 0; i < this.q.split("&").length; i++) {
                this.keyValuePairs[i] = this.q.split("&")[i];
            }
        }

        this.getKeyValuePairs = function () {
            return this.keyValuePairs;
        };

        this.getRawValue = function (key) {
            var j;
            for (j = 0; j < this.keyValuePairs.length; j++) {
                if (this.keyValuePairs[j].split("=")[0] == key)
                    return this.keyValuePairs[j].split("=")[1];
            }
            return false;
        };

        this.getValue = function (key) {
            return unescape(this.getRawValue(key));
        };

        this.getParameters = function () {
            var a, j;
            a = new Array(this.getLength());
            for (j = 0; j < this.keyValuePairs.length; j++) {
                a[j] = this.keyValuePairs[j].split("=")[0];
            }
            return a;
        };

        this.getLength = function () {
            return this.keyValuePairs.length;
        };
    };
    /*end jslint ignore*/

    global.maxInt32 = Math.pow(2, 31);

    global.rand = (function () {
        // Get a random float less than 1, positive.
        function nextFloat() {
            return Math.random();
        }

        // Get a random float in range: 0 <= result < high.
        function nextRangedFloat(high) {
            return Math.random() * high;
        }

        // Get a random integer in range: 0 <= result < high.
        function nextRangedInt(high) {
            return Math.floor(Math.random() * high);
        }

        // Get a random integer (32-bit signed, positive only).
        function nextInt32() {
            return Math.floor(Math.random() * global.maxInt32);
        }

        // Get a random boolean.
        function nextBool() {
            return Math.random() >= 0.5;
        }

        return {
            nextFloat: nextFloat,
            nextRangedFloat: nextRangedFloat,
            nextRangedInt: nextRangedInt,
            nextInt32: nextInt32,
            nextBool: nextBool
        };
    } ());

} (this));
