/// <reference path="sprite.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignVisuals.js" />
(function (global) {
    "use strict";

    var $ = global.jQuery,
        Vector = global.Vector,
        sjs = global.sjs,
        visuals = global.visuals,
        starMap = global.starMap;

    global.controls = (function () {
        var scene, input,
            mouseDownPosition, mouseIsDragging, mousePrev, mouseDragThreshold = 3;

        function captureMousePrev() {
            mousePrev = {
                down: input.mouse.down,
                position: new Vector(input.mouse.position.x, input.mouse.position.y)
            };
        }

        function init(inScene) {
            scene = inScene;
            input = sjs.Input(scene);

            // When the mouse button is pressed the mouse position is stored here.
            mouseDownPosition = new Vector(0, 0);
            mouseIsDragging = false;
            captureMousePrev();
        }

        function mouseClicked() {
            var d = $('<div></div>')
                .load('../markup/dialogs.html #solar')
			    .dialog({
			        autoOpen: false,
			        title: 'poo bums',
			        width: 500,
			        height: 300
			    });

            d.dialog('open');
        }

        function handleInput() {
            var mousePosVector, mouseThisDist, mouseDragLength;

            mousePosVector = new Vector(input.mouse.position.x, input.mouse.position.y);
            mouseThisDist = (function () {
                //TODO: make this "lazy" again.
                return mousePrev.position.sub(mousePosVector);
            } ());

            if (!input.mouse.down) {
                if (!mouseIsDragging && mousePrev.down) {
                    // A click occurred.
                    mouseClicked();
                }

                mouseIsDragging = false;
            } else {
                if (!mousePrev.down) {
                    mouseDownPosition = mousePosVector;
                }

                if (!mouseIsDragging) {
                    // then see if there was a click or the start of a drag.
                    mouseDragLength = (function () {
                        var val, nowMousePos;
                        nowMousePos = mousePosVector;
                        val = mouseDownPosition.sub(nowMousePos);
                        return val.length();
                    } ());

                    if (mouseDragLength > mouseDragThreshold) {
                        // Started dragging the screen.
                        mouseIsDragging = true;
                    }
                }
            }

            if (mouseIsDragging) {
                (function () {
                    var xDist, yDist, newX, newY, prePos = visuals.viewpos();

                    if (input.mouse.down) {
                        xDist = mousePrev.position.x - mousePosVector.x;
                        yDist = mousePrev.position.y - mousePosVector.y;

                        newX = prePos.x + xDist;
                        newY = prePos.y + yDist;
                    } else {
                        newX = prePos.x;
                        newY = prePos.y;
                    }

                    function changeViewPos(newX, newY) {
                        var x, y;
                        x = global.withinBounds(newX, 0, starMap.size.x);
                        y = global.withinBounds(newY, 0, starMap.size.y);
                        visuals.viewpos(new Vector(x, y));
                    }
                    changeViewPos(newX, newY);
                } ());
            }

            captureMousePrev();
        }

        return {
            init: init,
            handleInput: handleInput
        };
    } ());
} (this));
