/// <reference path="cmnMisc.js" />
/// <reference path="cmnSpatial.js" />
/// <reference path="SpaceReignTypes.js" />
(function (global) {
    "use strict";
    var Vector = global.Vector,
        TradeItem = global.TradeItem,
        TradeGoods = global.TradeGoods,
        Solar = global.Solar,
        ShipClass = global.ShipClass,
        Vessel = global.Vessel,
        spatial = global.spatial,
        rand = global.rand;

    global.initialSettings = (function () {
        var timeMarginFraction = 0.2;

        return {
            epsilon: 0.01,

            // Set a margin that the Governor tries to keep processing time within desired frame rate.
            timeMarginMultiplier: 1.0 - timeMarginFraction,
            minMarginFraction: 0.01,

            // Used in Governor to determine when to update workload proportions.
            numItersToWait: 5,

            // Average number of stars in the universe.
            numberOfSolarSystems: 40000,

            initialNumberOfShips: 600,

            sectorSize: 500.0,
            sectorDepth: 1000.0,
            sectorCountHorizontal: 80,
            sectorCountVertical: 48,

            maxZoom: 0.01,
            minZoom: 2.0,
            defZoom: 0.25,

            fov: Math.PI * (1.0 - 1.0 / 2.0),
            zNearest: 1.0,
            zFurthest: 100000.0,

            framesPerSecond: 30
        };
    } ());

    // Space is made up of sectors of solar systems.
    global.starMap = (function () {
        var space, sectorSize, sectorHalfSize, sectorCount, size, halfSize, margin,
            numberOfSectors, minStarsPerSector, maxStarsPerSector,
            averageStarsPerSector, rangeStarsPerSector,
            ix, iy, ar,
            v2 = new Vector(2, 2, 2);

        sectorSize = (function () {
            var size, depth;
            size = global.initialSettings.sectorSize;
            depth = global.initialSettings.sectorDepth;
            return new Vector(size, size, depth);
        } ());
        sectorHalfSize = sectorSize.div(v2);
        sectorCount = new Vector(
            global.initialSettings.sectorCountHorizontal,
            global.initialSettings.sectorCountVertical);
        size = sectorSize.mul(sectorCount);
        halfSize = size.div(v2);

        // // Propagate the star map with solar systems.
        // var universe = [ for i in 1..ginitialSettings.NumberOfSolarSystems -> Solar.CreateSolar <| (rand.Random(mSize), rand) ]
        //
        // // A function to pull all the stars out of a sector of the universe.
        // var getSolarsWithin (offX:int) (offY:int) =
        // var topLeft = new Vector(mSectorSize.x * float32 offX, mSectorSize.y * float32 offY)
        // //var bottomRight = sectorSize + topLeft |> fun s -> {FlatPoint.x = s.x; y = s.y}
        // var bottomRight = new Vector(mSectorSize.x + topLeft.x, mSectorSize.y + topLeft.y)
        // var isWithin = fun c ->
        // Spatial.CoordIsWithin(topLeft, bottomRight, c)
        // {   solars =
        // universe
        // |> List.choose (fun s -> if isWithin s.coord then Some(s) else None)
        // |> List.sortWith (fun s1 s2 -> Spatial.Compare(s1.coord,s2.coord))
        // }
        //
        // // Create the star map of sectors.
        // var v = Array2D.init mSectorCount.x mSectorCount.y getSolarsWithin
        //
        // v

        numberOfSectors = sectorCount.x * sectorCount.y;
        averageStarsPerSector = global.initialSettings.numberOfSolarSystems / numberOfSectors;
        margin = Math.max(1, averageStarsPerSector / 10);
        minStarsPerSector = Math.max(0, averageStarsPerSector - margin);
        maxStarsPerSector = averageStarsPerSector + margin;
        rangeStarsPerSector = maxStarsPerSector - minStarsPerSector + 1;

        // This creates a solar system within the specified area.
        function createSolar(area/*Vector*/) {
            var i, sol;

            function makeTradeItem() {
                var ti = new TradeItem();
                ti.ImportPrice = rand.nextInt32();
                ti.ExportPrice = rand.nextInt32();
                ti.Quantity = rand.nextInt32();
                return ti;
            }

            sol = new Solar();
            sol.coord = area;
            sol.inhabited = rand.nextBool();
            for (i = 0; i < TradeGoods.TradeItemNames.length; i++) {
                sol.tradeItems.push(makeTradeItem());
            }
            return sol;
        }

        //function createSolarWithin(topLeft/*Vector*/, bottomRight/*Vector*/) {
        //    return createSolar(rand.nextVectorFloat(bottomRight.sub(topLeft)).add(topLeft));
        //}

        // Create stars in a sector of the universe.
        function createSectorSolars(offX, offY) {
            var i, topLeft, bottomRight, numSolars, sols;

            topLeft = new Vector(sectorSize.x * offX, sectorSize.y * offY, 0.0);
            bottomRight = new Vector(topLeft.x + sectorSize.x, topLeft.y + sectorSize.y, size.z);
            numSolars = minStarsPerSector + rand.nextRangedInt(rangeStarsPerSector);

            sols = [];
            for (i = 1; i <= numSolars; i++) {
                //sols.push(createSolarWithin(topLeft, bottomRight));
                sols.push(createSolar(rand.nextVectorFloat(sectorSize)));
            }
            sols.sort(function (s1, s2) {
                return spatial.compare(s1.coord, s2.coord);
            });
            return sols;
        }

        // Create the star map of sectors.
        space = [];
        for (ix = 0; ix < sectorCount.x; ix++) {
            ar = [];
            for (iy = 0; iy < sectorCount.y; iy++) {
                ar[iy] = createSectorSolars(ix, iy);
            }
            space[ix] = ar;
        }

        return {
            // Sectors define space as a checker board.
            // The size of a sector as a vector.
            sectorSize: sectorSize,

            // Half the size of a sector as a vector.
            sectorHalfSize: sectorHalfSize,

            // How many sectors the star map is divided into, horizontally and vertically.
            // This is also bottom-right back-most point of space.
            sectorCount: sectorCount,

            // The top-left front-most point of space is zero.
            zero: new Vector(0, 0, 0),

            // This is also bottom-right back-most point of space.
            size: size,

            // Half the size of the star map.
            halfSize: halfSize,

            // The star map.
            space: space
        };
    } ());

    // The types of vessel class available.
    global.shipClasses = (function () {
        var ar = [];

        // Standard ships move by warping space.
        ar.push(new ShipClass('Runt', 1.0));
        ar.push(new ShipClass('Rump', 2.5));

        // This class of ship doesn't move but travels by folding space. (AKA. heighliner)
        ar.push(new ShipClass('Void-folder', 0.0));

        return ar;
    } ());

    global.vessels = (function () {
        var taskStateIndex, taskPortion, allShips;

        allShips = (function () {
            var i, ar;

            function makeShip() {
                var classIndex, vx, vy, coord, dest, ship,
                    v2 = new Vector(2, 2);

                function chooseSystem() {
                    var sectorCenter, solars;
                    sectorCenter = global.starMap.sectorCount.div(v2);
                    solars = global.starMap.space[sectorCenter.x][sectorCenter.y];
                    if (solars.length === 0) {
                        // A fix for when a sector doesn't have any stars.
                        return new Solar();
                    }
                    return solars[rand.nextRangedInt(solars.length)];
                }

                // Now make the Vessel object.
                classIndex = rand.nextRangedInt(global.shipClasses.length);
                vx = rand.nextRangedFloat(global.starMap.sectorSize.x);
                vy = rand.nextRangedFloat(global.starMap.sectorSize.y);
                coord = global.starMap.size.div(v2).add(new Vector(vx, vy, 0));
                dest = chooseSystem();
                ship = new Vessel(classIndex, coord, dest);
                return ship;
            }

            ar = [];
            for (i = 0; i < global.initialSettings.initialNumberOfShips; i++) {
                ar.push(makeShip());
            }
            return ar;
        } ());

        // This is how far through the ship list "iterateTask" has traversed.
        taskStateIndex = 0;

        // Here is the portion that "iterateTask" is allowed process in one calling.
        taskPortion = global.maxInt32;

        return {
            // Return how many jobs "iterateTask" needs to do. (The number of ships currently in transit.)
            taskCount: function () {
                return allShips.length;
            },

            // Here is the portion that "iterateTask" is allowed process in one calling.
            taskPortion: taskPortion,

            allShips: allShips,

            // This manages the coordination of vessels.
            iterateTask: function () {
                var i, s, startIndex, tuple, endIndex, extraEndIndex,
                    dilation = allShips.length / taskPortion;

                // A function to move a coordinate closer to a destination.
                // Returns the tuple (newCoordinate : DepthPoint, isAtDestination : bool)
                function moveStep(hereCoord, thereCoord, moveDistance) {
                    var distCoord, fullDistance, ratio, ratioVector, result;

                    distCoord = thereCoord.sub(hereCoord);
                    fullDistance = distCoord.length;
                    if (moveDistance > fullDistance) {
                        // The move distance will over-shoot the target, so just return the destination.
                        return {
                            coord: thereCoord,
                            arrived: true
                        };
                    }
                    ratio = moveDistance / fullDistance;
                    ratioVector = new Vector(ratio, ratio);
                    result = hereCoord.add(distCoord).mul(ratioVector);
                    return {
                        coord: result,
                        arrived: false
                    };
                }

                // A function to move a ship closer to it's destination.
                function moveShip(ship) {
                    if (!ship.arrived) {
                        var v = moveStep(ship.coord, ship.dest.coord, (global.shipClasses[ship.classIndex].speed * dilation));
                        ship.coord = v.coord;
                        ship.arrived = v.arrived;
                    }
                }

                // Move the allowed portion of ships *that are currently in transit*.
                startIndex = taskStateIndex;
                tuple = (function () {
                    var e, count;

                    count = allShips.length;
                    e = -1 + startIndex + (taskPortion > count ? count : taskPortion);

                    if (e < count) {
                        return [e, -1];
                    } else {
                        return [count - 1, e - count];
                    }
                } ());
                endIndex = tuple[0];
                extraEndIndex = tuple[1];

                // Here I should be splitting the list into left, middle and right segments
                // and then joining them back after, perhaps.

                // Do the right portion.
                for (i = startIndex; i <= endIndex; i++) {
                    moveShip(allShips[i]);
                }

                // Do the left portion.
                if (extraEndIndex >= 0) {
                    for (i = 0; i <= extraEndIndex; i++) {
                        moveShip(allShips[i]);
                    }
                    taskStateIndex = extraEndIndex + 1;
                } else {
                    s = endIndex + 1;
                    taskStateIndex = (s === allShips.length) ? 0 : s;
                }
            }
        };
    } ());

    global.governor = (function () {
        var portionMultiplier, reproportioningCountdown;

        // The task portion allowance, it is the multiplier of each task's total job count.
        // (It will never be greater than 1.0, but always greater than 0.0)
        portionMultiplier = 1.0;

        // A count of how many iterations have passed since the last proportioning.
        reproportioningCountdown = 0;

        // Set the portion allowance for each task, based on the mportionMultiplier.
        // Basically there should be a portion field in the module of each task,
        // and this function will alter that number when a new mportionMultiplier is set.
        function doApportioning() {
            global.vessels.taskPortion = portionMultiplier * global.vessels.taskCount();
        }

        // Get each task to do it's thing.
        function doTasks() {
            // Move a portion of the vessels.
            global.vessels.iterateTask();

            // Work out how much to divide each task's workload.
            if (reproportioningCountdown === 0) {
                //var paintTimeAverage = visualizer.PaintTimer.ElapsedMilliseconds / float InitialSettings.NumItersToWait
                //var taskTimeAverage = float taskTimer.ElapsedMilliseconds / float InitialSettings.NumItersToWait
                //visualizer.PaintTimer.Reset()
                //taskTimer.Reset()

                // Reset the counter.
                reproportioningCountdown = global.initialSettings.numItersToWait;

                // Set a new divisor of portions.
                var portionMultiplier = (function () {
                    var timeAllowance, timeMargin, p, halfP;

                    // Deduct from "frame rate" the "painting time" to get "allowed processing time".
                    timeAllowance = 1;
                    //visualizer.MillisecondsPerFrame - paintTimeAverage

                    // Reduce that time by a margin.
                    timeMargin = timeAllowance * global.initialSettings.timeMarginMultiplier;

                    //p = mportionMultiplier * timeMargin / taskTimeAverage
                    //p = timeMargin / taskTimeAverage;
                    p = timeMargin;

                    if (p > 1) {
                        //viz.StepUpFps()
                        //recomputeFormTimer ()
                        return 1;
                    } else if (p > 0) {
                        return p;
                    } else {
                        //viz.StepDownFps()
                        //recomputeFormTimer ()
                        halfP = portionMultiplier / 2;
                        if (halfP > global.initialSettings.minMarginFraction) {
                            return halfP;
                        } else {
                            return global.initialSettings.minMarginFraction;
                        }
                    }
                }());
                // Now to set the new portion allowance in all tasks.
                doApportioning();
            } else {
                reproportioningCountdown--;
            }
        }

        return {
            initialize: function () {
                //taskTimer.Start()
                global.governor.recomputeGameTimings(1);
                //visualizer.FramesPerSecond
            },

            recomputeGameTimings: function (/*fps*/) {
                //visualizer.FramesPerSecond <- fps
            },

            // Manage the tasks.
            iterateTasks: function () {
                // Run all tasks.
                doTasks();
            }
        };
    }());
} (this));
