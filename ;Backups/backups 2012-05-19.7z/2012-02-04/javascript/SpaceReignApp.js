/// <reference path="sprite.js" />
/// <reference path="cmnMisc.js" />
/// <reference path="SpaceReignSingleton.js" />
/// <reference path="SpaceReignTypes.js" />
/// <reference path="SpaceReignVisuals.js" />
/// <reference path="SpaceReignControls.js" />
(function (global) {
    "use strict";

    var main,
        $ = global.jQuery,
        sjs = global.sjs,
        visuals = global.visuals,
        controls = global.controls,
        vessels = global.vessels;

    // A game inspired by the Amiga game: Supremacy. (and Megalomania, The Settlers, Elite...)
    // Codename: Reign
    // Proposed Title: Space Reign
    // Nasher
    main = (function () {
        var scene;

        function runGame() {
            var ticker;
            ticker = scene.Ticker(function () {
                controls.handleInput();
                visuals.draw();
                vessels.iterateTask();
            });
            ticker.run();
        }

        function init() {
            var winWidth = $(window).width(),
                winHeight = $(window).height();

            // Create the scene object.
            // Draw using the HTML5 canvas element.
            scene = sjs.Scene({
                w: winWidth,
                h: winHeight,
                useCanvas: true
            });

            controls.init(scene);
            visuals.init(scene);

            // Load the images in parallel and run the game once loaded.
            scene.loadImages(visuals.imageNames, runGame);
        }

        function begin() {
            init();
        }

        function resized() {
            scene.remove();
            init();
        }

        return {
            begin: begin,
            resized: resized
        };
    } ());

    $(document).ready(main.begin);
    $(window).resize(main.resized);
} (this));
