/// <reference path="cmnMisc.js" />
(function (global) {
    "use strict";

    global.Bounds = function (l, r, t, b) {
        this.left = l;
        this.right = r;
        this.top = t;
        this.bottom = b;
    };
    global.Bounds.prototype.width = function () {
        return this.right - this.left;
    };
    global.Bounds.prototype.height = function () {
        return this.bottom - this.top;
    };

    // A vector type.
    global.Vector = (function () {
        var V = function (x, y, z) {
            this.x = x;
            this.y = y;
            this.z = (z === undefined || isNaN(z)) ? 0 : z;
        };

        function vectorMath(mathFunc, first, second) {
            if (second instanceof V) {
                return new V(mathFunc(first.x, second.x),
                             mathFunc(first.y, second.y),
                             mathFunc(first.z, second.z));
            }

            throw "vectorMath";
        }

        V.prototype.add = function (other) {
            var mathFunc = function (t, o) {
                return t + o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.sub = function (other) {
            var mathFunc = function (t, o) {
                return t - o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.mul = function (other) {
            var mathFunc = function (t, o) {
                return t * o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.div = function (other) {
            var mathFunc = function (t, o) {
                return t / o;
            };
            return vectorMath(mathFunc, this, other);
        };

        V.prototype.length = function () {
            return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        };

        return V;
    } ());

    var Vector = global.Vector;

    // Make a random point within a volume. (integer)
    global.rand.nextVectorFloat = function (area/*Vector*/) {
        var x, y, z;
        x = this.nextRangedFloat(area.x);
        y = this.nextRangedFloat(area.y);
        z = this.nextRangedFloat(area.z);
        return new Vector(x, y, z);
    };

    // Make a random point within a volume. (integer)
    global.rand.nextVectorInt = function (area/*Vector*/) {
        var x, y, z;
        x = this.nextRangedInt(area.x);
        y = this.nextRangedInt(area.y);
        z = this.nextRangedInt(area.z);
        return new Vector(x, y, z);
    };

    global.spatial = (function () {
        // Compare vectors using predetermined precedence.
        function compare(first, second) {
            if (first instanceof Vector && second instanceof Vector) {
                if (first.Z < second.Z) {
                    return -1;
                }
                if (first.Z > second.Z) {
                    return 1;
                }
            }
            if (first.Y < second.Y) {
                return -1;
            }
            if (first.Y > second.Y) {
                return 1;
            }
            if (first.X < second.X) {
                return -1;
            }
            if (first.X > second.X) {
                return 1;
            }
            return 0;
        }

        // Returns true if the coord is within the topRight to bottomLeft bounds.
        function coordIsWithin(topLeft, bottomRight, coord) {
            return coord.X >= topLeft.X && coord.Y >= topLeft.Y && coord.X < bottomRight.X && coord.Y < bottomRight.Y;
        }

        return {
            compare: compare,
            coordIsWithin: coordIsWithin
        };
    } ());
} (this));
